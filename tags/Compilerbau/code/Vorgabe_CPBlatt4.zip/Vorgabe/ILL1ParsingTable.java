import java.util.Map.Entry;
import java.util.List;
import java.util.Map;

public interface ILL1ParsingTable {
    public List<String> get(String nonterminal, String terminal);
    
    public String getStartSymbol();
    
    public List<String> getNonterminals();
    
    public List<String> getTerminals();
    
    public String getEpsilon();
}