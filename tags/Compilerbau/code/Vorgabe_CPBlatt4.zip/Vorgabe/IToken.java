public interface IToken {
        public String toString();
        public Object getValue();
}