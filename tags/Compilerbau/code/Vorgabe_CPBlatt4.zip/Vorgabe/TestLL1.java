// javac -cp .:junit-4.12.jar:hamcrest-core-1.3.jar TestLL1.java
// java -cp .:junit-4.12.jar:hamcrest-core-1.3.jar org.junit.runner.JUnitCore TestLL1

import static org.junit.Assert.assertEquals;

import static org.junit.Assert.assertTrue;
import org.junit.Test;
import org.junit.Before;


import junit.framework.TestCase;
import java.util.Map.Entry;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.AbstractMap.SimpleEntry;
import java.util.Arrays;

import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;


public class TestLL1{
    
    private LL1ParsingTable table0;
    private LL1ParsingTable table1;
    
    @Before
    public void setUp()
    {
        initTable0();
        initTable1();
    }
    
    private void initTable0()
    {
        /*
         S -> a
         S -> i E t S
         E -> b
         */
        List<String> nonterminals = new ArrayList<String>();
        String narray[] = {"S","E"};
        nonterminals = Arrays.asList(narray);
        
        List<String> terminals = new ArrayList<String>();
        String tarray[] = {"a","b","e","i","t"};
        terminals = Arrays.asList(tarray);
        
        String startSymbol = "S";
        String epsilonSymbol = "epsilon";
        
        Map<Entry<String,String>,List<String>> map;
        map = new HashMap<Entry<String,String>, List<String>>();
        String production0[] = {"a"};
        map.put(new SimpleEntry("S","a"), Arrays.asList(production0));
        String production1[] = {"i","E","t","S"};
        map.put(new SimpleEntry("S","i"), Arrays.asList(production1));
        String production2[] = {"b"};
        map.put(new SimpleEntry("E","b"), Arrays.asList(production2));
        
        table0 =  new LL1ParsingTable(nonterminals, terminals,
                                     startSymbol, epsilonSymbol, map);
    }
    
    private void initTable1()
    {
        /*
         Folie 4b/32
         */
        List<String> nonterminals = new ArrayList<String>();
        String narray[] = {"E", "T", "E2", "T2", "F"};
        nonterminals = Arrays.asList(narray);
        
        List<String> terminals = new ArrayList<String>();
        String tarray[] = {"id","+","*","(",")"};
        terminals = Arrays.asList(tarray);
        
        String startSymbol = "E";
        String epsilonSymbol = "epsilon";
        
        Map<Entry<String,String>,List<String>> map;
        map = new HashMap<Entry<String,String>, List<String>>();
        String production0[] = {"T","E2"};
        map.put(new SimpleEntry("E","id"), Arrays.asList(production0));
        String production1[] = {"T","E2"};
        map.put(new SimpleEntry("E","("), Arrays.asList(production1));
        String production2[] = {"+", "T","E2"};
        map.put(new SimpleEntry("E2","+"), Arrays.asList(production2));
        String production3[] = {"epsilon"};
        map.put(new SimpleEntry("E2",")"), Arrays.asList(production3));
        String production4[] = {"epsilon"};
        map.put(new SimpleEntry("E2","$"), Arrays.asList(production4));
        String production5[] = {"F","T2"};
        map.put(new SimpleEntry("T","id"), Arrays.asList(production5));
        String production6[] = {"F","T2"};
        map.put(new SimpleEntry("T","("), Arrays.asList(production6));
        String production7[] = {"epsilon"};
        map.put(new SimpleEntry("T2","+"), Arrays.asList(production7));
        String production8[] = {"*","F","T2"};
        map.put(new SimpleEntry("T2","*"), Arrays.asList(production8));
        String production9[] = {"epsilon"};
        map.put(new SimpleEntry("T2",")"), Arrays.asList(production9));
        String production10[] = {"epsilon"};
        map.put(new SimpleEntry("T2","$"), Arrays.asList(production10));
        String production11[] = {"id"};
        map.put(new SimpleEntry("F","id"), Arrays.asList(production11));
        String production12[] = {"(","E", ")"};
        map.put(new SimpleEntry("F","("), Arrays.asList(production12));
        
        table1 =  new LL1ParsingTable(nonterminals, terminals,
                                      startSymbol, epsilonSymbol, map);
    }
    
    @Test
    public void testIfThenElse() throws MyParseException
    {
        LL1Parser parser = new LL1Parser(table0);
        
        String token0[] = {"i","b","t","a"};
        assertTrue(parser.parse(Arrays.asList(token0)));
        String token2[] = {"i","b","t", "i", "b", "t", "a"};
        assertTrue(parser.parse(Arrays.asList(token2)));
        String token3[] = {"i","b","t", "i", "b", "t", "i", "b", "t", "a"};
        assertTrue(parser.parse(Arrays.asList(token3)));
    }
    

    @Test(expected = MyParseException.class)
    public void testException0() throws MyParseException
    {
        LL1Parser parser = new LL1Parser(table0);
        String token1[] = {"i","b","t"};
        parser.parse(Arrays.asList(token1));
    }
    
    @Test(expected = MyParseException.class)
    public void testException1() throws MyParseException
    {
        LL1Parser parser = new LL1Parser(table0);
        String token1[] = {"i","b","t","t"};
        parser.parse(Arrays.asList(token1));
    }
    
    @Test
    public void testArithExpression() throws MyParseException
    {
        LL1Parser parser = new LL1Parser(table1);
        
        String token0[] = {"id","+","id","*", "id"};
        assertTrue(parser.parse(Arrays.asList(token0)));
        String token1[] = {"id","*","id","*", "id"};
        assertTrue(parser.parse(Arrays.asList(token1)));
        String token2[] = {"id","+","id"};
        assertTrue(parser.parse(Arrays.asList(token2)));
    }
    
    
    @Test
    public void testZusatzaufgabe0() throws MyParseException, LexerException, IOException
    {
        FileReader fr = new FileReader("input.txt");
        BufferedReader br = new BufferedReader(fr);
        StringBuilder sb = new StringBuilder();
        String line = br.readLine();
        while(line!=null){
            sb.append(line);
            line = br.readLine();
        }
        br.close();
        ILexer lexer = new IDLexer(sb.toString());
        LL1Parser parser = new LL1Parser(table1);
        parser.parse(lexer);
    }
    
    
    @Test
    public void testZusatzaufgabe1() throws MyParseException, LexerException, IOException
    {
        FileReader fr = new FileReader("input2.txt");
        BufferedReader br = new BufferedReader(fr);
        StringBuilder sb = new StringBuilder();
        String line = br.readLine();
        while(line!=null){
            sb.append(line);
            line = br.readLine();
        }
        br.close();
        ILexer lexer = new IFLexer(sb.toString());
        LL1Parser parser = new LL1Parser(table0);
        parser.parse(lexer);
    }
     
    
    @Test(expected = MyParseException.class)
    public void testException2() throws MyParseException
    {
        LL1Parser parser = new LL1Parser(table1);
        String token0[] = {"id","id"};
        assertTrue(parser.parse(Arrays.asList(token0)));
    }
}