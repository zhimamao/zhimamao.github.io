public interface ILexer {
        public boolean hasMore();
        public void advance() throws LexerException;
        public boolean eat(String token);
        public IToken getNext();
}