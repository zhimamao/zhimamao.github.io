import java.util.Set;
import java.util.List;

public interface INode {
    public void addTransition(INode dest, char c);
    public Set<INode> getNext(char c);
    public String getName();
    public boolean isFinal();
    public List<Edge> getEdges();
    public Set<INode> getTransition(char c);
    public void setFinal();
}
