import java.util.Set;

public class DFA {
    private INode start;
    private Set<INode> nodes;
    private Set<IEdge> edges;

    public DFA(Set<INode> nodes, INode start, Set<IEdge> edges) {
        this.start = start;
        this.nodes = nodes;
        this.edges = edges;

        for (IEdge edge : edges) {
            edge.getStart().addTransition(edge.getEnd(), edge.getChar());
        }
    }

    public Set<INode> getNodes()
    {
        return nodes;
    }
    
    public INode getStart() {
        return start;
    }

    public String accept(String word, INode current) {
        if (current == null)
            return " ablehnen";

        if (word == null || word.length() == 0) {
            if (current.isFinal()) {
                return current + " akzeptieren";
            } else {
                return current + " ablehnen";
            }
        }

        return current + accept(word.substring(1), current.getNext(word.charAt(0)).iterator().next());
    }

    public String accept(String word) {
        return accept(word, start);
    }
}
