/**
 * Created by Nk on 30.10.2015.
 */
public class Edge implements IEdge {
    private INode start;
    private INode end;
    private char c;

    public Edge(INode start, char c, INode end) {
        this.start = start;
        this.c = c;
        this.end = end;
    }
    
    public INode getStart(){
        return start;
    }
    
    public INode getEnd(){
        return end;
    }
    
    public char getChar(){
        return c;
    }
}
