import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.HashSet;


public class Node implements INode {
    private String name;
    private boolean isFinal;
    private List<Edge> edges = new ArrayList<>();

    public Node(String nodeName, boolean nodeIsFinal) {
        this.name = nodeName;
        this.isFinal = nodeIsFinal;
    }

    @Override
    public void addTransition(INode dest, char c) {
        Edge edge = new Edge(this, c, dest);
        edges.add(edge);
    }
    
    public List<Edge> getEdges()
    {
        return edges;
    }

    @Override
    public Set<INode> getNext(char c) {
        Set<INode> nodes = epsilonClosure();
        Set<INode> result = new HashSet<INode>();
        for(INode node: nodes)
        {
            Set<INode> transitions = node.getTransition(c);
            if(transitions!=null)
                result.addAll(transitions);
        }
        return result;
    }
    
    
    public Set<INode> getTransition(char c) {
        Set<INode> next = new HashSet<INode>();
        for(Edge edge: edges) {
            if (edge.getChar() == c) {
                next.add(edge.getEnd());
            }
        }
        return next.isEmpty() ? null : next;
    }
    
    public Set<INode> epsilonClosure()
    {
        Set<INode> result = new HashSet<INode>();
        result.add(this);
        int size;
        if(result!=null)
            do{
                size = result.size();
                Set<INode> newSet = new HashSet<INode>();
                newSet.addAll(result);
                for(INode n: result)
                {
                    Set<INode> next = n.getTransition('\0');
                    if(next!=null)
                        newSet.addAll(next);
                }
                result = newSet;
            }while(size!=result.size());
        return result;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public boolean isFinal() {
        return isFinal;
    }
    
    @Override
    public void setFinal()
    {
        isFinal = true;
    }
}
