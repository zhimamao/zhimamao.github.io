import java.util.Set;
import java.util.HashSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

public class NFA {
    private Set<Character> alphabet;
    private Set<INode> nodes;
    private Set<IEdge> edges;
    private INode start;
    
    
    public NFA(Set<Character> alphabet, Set<INode> nodes, INode start, Set<IEdge> edges)
    {
        this.alphabet = alphabet;
        this.nodes = nodes;
        this.start = start;
        this.edges = edges;
        
        for(IEdge edge: edges) {
            edge.getStart().addTransition(edge.getEnd(), edge.getChar());
        }
    }

    public Set<INode> getNodes()
    {
        return nodes;
    }
    
    public INode getStart()
    {
        return start;
    }
    
    public Set<List<INode>> allPaths(String word) {
        Set<List<INode>> result = new HashSet<List<INode>>();
        List<INode> emptyPath = new ArrayList<INode>();
        emptyPath.add(start);
        result.add(emptyPath);
        
        
        for(int i=0; i<word.length(); i++) {
            char c = word.charAt(i);
            Set<List<INode>> update = new HashSet<List<INode>>();
            for(List<INode> path:result)
            {
                INode lastNode = path.get(path.size()-1);
                Set<INode> next = lastNode.getNext(c);
                if(next!=null){
                    for(INode node : next){
                        List<INode> newPath = new ArrayList<INode>();
                        newPath.addAll(path);
                        newPath.add(node);
                        update.add(newPath);
                    }
                }
                
            }
            result = update;
        }
        
        return result;
    }
    
    String accept(String word) {
        Set<List<INode>> allPaths = allPaths(word);
        
        for(List<INode> path:allPaths)
            if(path.get(path.size()-1).isFinal())
            {
                StringBuilder msg = new StringBuilder();
                for(INode node: path)
                {
                    msg.append(node.getName());
                }
                msg.append(" akzeptieren");
                return msg.toString();
            }
        return "ablehnen";
    }
    
    public DFA toDFA() {
        Set<Set<INode>> dfaNodes = new HashSet<>();
        Set<Set<INode>> oldDFANodes = new HashSet<>();
        
        Set<INode> dfaStart = ((Node) start).epsilonClosure();
        oldDFANodes.add(dfaStart);
        
        Map<Set<INode>, INode> map = new HashMap<>();
        map.put(dfaStart, getDFANodeForNFANodes(dfaStart));
        
        while (!dfaNodes.equals(oldDFANodes)) {
            dfaNodes.addAll(oldDFANodes);
            for (Set<INode> dfaNode : dfaNodes) {
                for (Character character : alphabet) {
                    Set<INode> nextForDFANode = new HashSet<>();
                    for (INode node : dfaNode) {
                        Set<INode> nextForNode = node.getNext(character);
                        for (INode n : nextForNode) {
                            nextForDFANode.addAll(((Node) n).epsilonClosure());
                        }
                    }
                    oldDFANodes.add(nextForDFANode);
                }
            }
        }
        
        dfaNodes.remove(dfaStart);
        for (Set<INode> nodes : dfaNodes) {
            map.put(nodes, getDFANodeForNFANodes(nodes));
        }
        
        
        Set<IEdge> edges = new HashSet<>();
        for (Set<INode> nfaNodes : map.keySet()) {
            for (Character character : alphabet) {
                Set<INode> nextForNFANodes = new HashSet<>();
                for (INode nfaNode : nfaNodes) {
                    Set<INode> nextForNFANode = nfaNode.getNext(character);
                    for (INode next : nextForNFANode) {
                        nextForNFANodes.addAll(((Node) next).epsilonClosure());
                    }
                }
                
                Edge edge = new Edge(map.get(nfaNodes), character, map.get(nextForNFANodes));
                edges.add(edge);
            }
        }
        
        Set<INode> nodes = new HashSet<>(map.values());
        DFA dfa = new DFA(nodes, map.get(dfaStart), edges);
        return dfa;
    }
    
    private String getName(Set<INode> nodes) {
        String name = "";
        for (INode node : nodes) {
            name += node.getName() + ",";
        }
        return name;
    }
    
    private INode getDFANodeForNFANodes(Set<INode> nfaNodes) {
        String name = "{";
        boolean isFinal = false;
        for (INode node : nfaNodes) {
            name += node.getName() + ",";
            if (node.isFinal())
                isFinal = true;
        }
        name = name.substring(0, name.length() - 1) + "}";
        return new Node(name, isFinal);
    }

}
