from ExprListener import ExprListener

class KeyPrinter(ExprListener):     
    def exitExpr(self, ctx):         
        print("Oh, a key!") 