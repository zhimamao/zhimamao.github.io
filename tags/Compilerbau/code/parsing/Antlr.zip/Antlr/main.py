import sys
from antlr4 import *
from ExprLexer import ExprLexer
from ExprParser import ExprParser
from KeyPrinter import KeyPrinter
from copy import deepcopy
 
def main(argv):
    input = FileStream(argv[1])
    lexer = ExprLexer(input)
    stream = CommonTokenStream(lexer)
    for t in stream.getText():
        print(t)
    for t in stream.tokens:
        print(t)
    print(isinstance(stream.tokens, list))
    fake = deepcopy(stream.tokens)
    parser = ExprParser(stream)
    tree = parser.prog()
    printer = KeyPrinter()
    walker = ParseTreeWalker()
    walker.walk(printer, tree)
 
if __name__ == '__main__':
    main(sys.argv)