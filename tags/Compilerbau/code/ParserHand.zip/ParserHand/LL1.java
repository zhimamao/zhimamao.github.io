
import java.io.DataInput;


public class LL1{
public static char tok;
public static int tokasint = 0;


public static void main(String[] args) throws java.io.IOException {
        System.out.println("LL(1) Parser by Michael Leuschel");
        System.out.println("--------------------------------");
	
	
	    advance();
	
        System.out.println("Starting parse process...");
	
	    Expr(0);
    	if(tokasint != -1 && tok!='\n' && tok!='\r') {
	    	System.out.print("Character remaining in input: <");
	        System.out.print(tok); System.out.println(">");
    	}
	
        System.out.println("Finished.");
        }

public static void advance() throws java.io.IOException {
 if(tokasint != -1)
  { tokasint = System.in.read();
    tok = (char) tokasint;
  }
    
}

public static void eat(char c) throws java.io.IOException {
    if(tok==c)
	advance();
    else
    {
	System.out.print("*** parser error, expected <");
	System.out.print(c);
	System.out.print("> instead of <");
	if(tokasint== -1)
		System.out.print("EOF");
	else
		System.out.print(tok);
	System.out.println(">");
    }
}

       


public static void Expr(int i) throws java.io.IOException
    {tab(i); System.out.println("+Expr");
    switch(tok) {
  case '(': /* Expr --> (Expr) ExprCont */
	 eat('('); Expr(i+1); eat(')'); ExprCont(i+1);
	  break;
  case '0': case '1': case '2': case '3': case '4':
  case '5': case '6': case '7': case '8': case '9':
	 /* Expr --> Num ExprCont */
	 Num(i+1); ExprCont(i+1);
	 break;
  default: eat('(');
    };
    tab(i); System.out.println("-Expr");
}

public static void ExprCont(int i) throws java.io.IOException
    {tab(i); System.out.println("+ExprCont");
	       switch(tok) {
  case ')': case '\r': case '\n': case (char) (-1): /* ExprCont --> epsilon */  break;
  case '+': case '*': case '/': case '-':
	 /* ExprCont --> (+|*|/|-) Expr */
	 advance(); Expr(i+1);
	 break;
  default: eat(')');
    }
}
	       
public static void Num(int i) throws java.io.IOException
    {tab(i); System.out.println("+Num");
    switch(tok) {
  case '0': advance(); break; /* Num --> 0 */
  case '1': case '2': case '3': case '4':
  case '5': case '6': case '7': case '8': case '9':
	       /* Num --> (1|2|3|4|5|6|7|8|9) DigStar */
	 advance(); DigStar(i+1); break;
  default: eat('0');
    }
}
public static void DigStar(int i) throws java.io.IOException
    {tab(i); System.out.println("+DigStar");
    switch(tok) {
  case ')': case '+': case '*': case '/': case '-':
  case '\r': case '\n': case (char) (-1):
     break; /* DigStar --> epsilon */
  case '0': case '1': case '2': case '3': case '4':
  case '5': case '6': case '7': case '8': case '9':
	       /* DigStar --> (1|2|3|4|5|6|7|8|9) DigStar */
	 advance(); DigStar(i+1); break;
  default: eat('0');
    }
}

public static int Char2Integer(char c) {
    char zero = '0';
    return ((int) c) - ((int) zero);
}

public static void tab(int i) {
    int j = i;
    while((j--) > 0)
     System.out.print('|');
     
}
}
