import java.util.Set;
import java.util.Map;

public interface IGrammarAnalyzer {

    public Set<String> getNullable();
    public Map<String, Set<String>> getFirst();
    public Map<String, Set<String>> getFollow();
    public ILL1ParsingTable getTable();

}