import java.util.List;

public class Grammar
{
    private List<String> nonterminals;
    private List<String> terminals;
    private String start;
    private List<Rule> productions;
    
    public Grammar(List<String> nonterminals, List<String> terminals, 
        String start, List<Rule> productions)
    {
        this.nonterminals = nonterminals;
        this.terminals = terminals;
        this.start = start;
        this.productions = productions;
    }
    
    public List<String> getNonterminals()
    {
        return nonterminals;
    }
    
    public List<String> getTerminals()
    {
        return terminals;
    }
    
    public String getStart()
    {
        return start;
    }
    
    public List<Rule> getProductions()
    {
        return productions;
    }
}