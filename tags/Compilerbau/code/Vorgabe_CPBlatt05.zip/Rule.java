import java.util.List;

public class Rule
{
    private String nonterminal;
    private List<String> production;
    
    public Rule(String nonterminal, List<String> production)
    {
        this.nonterminal = nonterminal;
        this.production  = production;
    }
    
    public String getNonterminal()
    {
        return nonterminal;
    }
    
    public List<String> getProduction()
    {
        return production;
    }
}