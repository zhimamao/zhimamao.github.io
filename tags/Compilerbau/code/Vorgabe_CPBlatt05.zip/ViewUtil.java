import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;
import java.util.AbstractMap.SimpleEntry;

public class ViewUtil {
    public ViewUtil() {
    }

    public static void main(String[] args) {
        if(args.length > 0 && args[0].equals("-tex")) {
            StringBuilder sb = new StringBuilder();
            sb.append("\n\\documentclass{article}\n");
            sb.append("\\usepackage[english]{babel}\n");
            sb.append("\\usepackage{adjustbox}\n");
            sb.append("\\begin{document}\n");
            sb.append(toTex(initGrammar1()));
            sb.append("\\end{document}\n");
            
            System.out.println(sb.toString());
        } else {
            System.out.println("java ViewUtil -tex > file");
        }
    }
    
    private static Grammar initGrammar0()
    {
        /*
         Z -> d
         Z -> X Y Z
         Y ->
         Y -> c
         X -> Y
         X -> a
         
         */
        
        String narray[] = {"X", "Y", "Z"};
        List<String> nonterminals = Arrays.asList(narray);
        
        String tarray[] = {"a","c","d","$"};
        List<String> terminals = Arrays.asList(tarray);
        
        String startSymbol = "Z";
        List<Rule> productions = new ArrayList<Rule>();
        String production0[] = {"d"};
        productions.add(new Rule("Z", Arrays.asList(production0)));
        String production1[] = {"X", "Y", "Z"};
        productions.add(new Rule("Z", Arrays.asList(production1)));
        productions.add(new Rule("Y", Collections.emptyList()));
        String production2[] = {"c"};
        productions.add(new Rule("Y", Arrays.asList(production2)));
        String production3[] = {"Y"};
        productions.add(new Rule("X", Arrays.asList(production3)));
        String production4[] = {"a"};
        productions.add(new Rule("X", Arrays.asList(production4)));
        
        return new Grammar(nonterminals, terminals,
                           startSymbol, productions);
    }
    
    
    private static Grammar initGrammar1()
    {
        /*
         E  -> T E'
         E' -> + T E'
         E' ->
         T  -> F T'
         T' -> * F T'
         T' ->
         F  -> ( E )
         F  -> id
         
         */
        
        String narray[] = {"E", "E'", "T", "T'", "F"};
        List<String> nonterminals = Arrays.asList(narray);
        
        String tarray[] = {"+","*","(",")","id", "$"};
        List<String> terminals = Arrays.asList(tarray);
        
        String startSymbol = "E";
        List<Rule> productions = new ArrayList<Rule>();
        String production0[] = {"T", "E'"};
        productions.add(new Rule("E", Arrays.asList(production0)));
        String production1[] = {"+", "T", "E'"};
        productions.add(new Rule("E'", Arrays.asList(production1)));
        productions.add(new Rule("E'", Collections.emptyList()));
        String production2[] = {"F", "T'"};
        productions.add(new Rule("T", Arrays.asList(production2)));
        String production3[] = {"*", "F", "T'"};
        productions.add(new Rule("T'", Arrays.asList(production3)));
        productions.add(new Rule("T'", Collections.emptyList()));
        String production4[] = {"(", "E", ")"};
        productions.add(new Rule("F", Arrays.asList(production4)));
        String production5[] = {"id"};
        productions.add(new Rule("F", Arrays.asList(production5)));
        
        return new Grammar(nonterminals, terminals,
                           startSymbol, productions);
    }
    
    private static Grammar initGrammar2()
    {
        /*
         S  -> [ A ]
         S  -> [ ]
         S  -> a
         A  -> A , S
         A  -> S
         */
        
        String narray[] = {"S", "A"};
        List<String> nonterminals = Arrays.asList(narray);
        
        String tarray[] = {"[","]","a",",", "$"};
        List<String> terminals = Arrays.asList(tarray);
        
        String startSymbol = "S";
        List<Rule> productions = new ArrayList<Rule>();
        String production0[] = {"[", "A", "]"};
        productions.add(new Rule("S", Arrays.asList(production0)));
        String production1[] = {"[", "]"};
        productions.add(new Rule("S", Arrays.asList(production1)));
        String production2[] = {"a"};
        productions.add(new Rule("S", Arrays.asList(production2)));
        String production3[] = {"A", ",", "S"};
        productions.add(new Rule("A", Arrays.asList(production3)));
        String production4[] = {"S"};
        productions.add(new Rule("A", Arrays.asList(production4)));
        
        return new Grammar(nonterminals, terminals,
                           startSymbol, productions);
    }
    
    private static Grammar initGrammar3()
    {
        /*
         S -> S + S
         S -> S S
         S -> ( S )
         S -> S *
         S -> a
         */
        
        String narray[] = {"S"};
        List<String> nonterminals = Arrays.asList(narray);
        
        String tarray[] = {"+","(",")","*", "a", "$"};
        List<String> terminals = Arrays.asList(tarray);
        
        String startSymbol = "S";
        List<Rule> productions = new ArrayList<Rule>();
        String production0[] = {"S", "+", "S"};
        productions.add(new Rule("S", Arrays.asList(production0)));
        String production1[] = {"S", "S"};
        productions.add(new Rule("S", Arrays.asList(production1)));
        String production2[] = {"(", "S", ")"};
        productions.add(new Rule("S", Arrays.asList(production2)));
        String production3[] = {"S", "*"};
        productions.add(new Rule("S", Arrays.asList(production3)));
        String production4[] = {"a"};
        productions.add(new Rule("S", Arrays.asList(production4)));
        
        return new Grammar(nonterminals, terminals,
                           startSymbol, productions);
    }
    
    
    private static Grammar initGrammar4()
    {
        /*
         S -> ( L )
         S -> a
         L -> L , S
         L -> S
         */
        
        String narray[] = {"S", "L"};
        List<String> nonterminals = Arrays.asList(narray);
        
        String tarray[] = {"(",")",",", "a", "$"};
        List<String> terminals = Arrays.asList(tarray);
        
        String startSymbol = "S";
        List<Rule> productions = new ArrayList<Rule>();
        String production0[] = {"(", "L", ")"};
        productions.add(new Rule("S", Arrays.asList(production0)));
        String production1[] = {"a"};
        productions.add(new Rule("S", Arrays.asList(production1)));
        String production2[] = {"L", ",", "S"};
        productions.add(new Rule("L", Arrays.asList(production2)));
        String production3[] = {"S"};
        productions.add(new Rule("L", Arrays.asList(production3)));
        
        
        return new Grammar(nonterminals, terminals,
                           startSymbol, productions);
    }
    
    
    private static Grammar initGrammar5()
    {
        /*
         S -> 0 S
         S -> S 1
         S -> 1 0
         */
        
        String narray[] = {"S"};
        List<String> nonterminals = Arrays.asList(narray);
        
        String tarray[] = {"0","1", "$"};
        List<String> terminals = Arrays.asList(tarray);
        
        String startSymbol = "S";
        List<Rule> productions = new ArrayList<Rule>();
        String production0[] = {"0", "S"};
        productions.add(new Rule("S", Arrays.asList(production0)));
        String production1[] = {"S", "1"};
        productions.add(new Rule("S", Arrays.asList(production1)));
        String production2[] = {"1", "0"};
        productions.add(new Rule("S", Arrays.asList(production2)));
        
        return new Grammar(nonterminals, terminals,
                           startSymbol, productions);
    }
    
    
    private static Grammar initGrammar6()
    {
        /*
         S -> S A
         S -> A
         A -> a
         */
        
        String narray[] = {"S", "A"};
        List<String> nonterminals = Arrays.asList(narray);
        
        String tarray[] = {"a", "$"};
        List<String> terminals = Arrays.asList(tarray);
        
        String startSymbol = "S";
        List<Rule> productions = new ArrayList<Rule>();
        String production0[] = {"S", "A"};
        productions.add(new Rule("S", Arrays.asList(production0)));
        String production1[] = {"A"};
        productions.add(new Rule("S", Arrays.asList(production1)));
        String production2[] = {"a"};
        productions.add(new Rule("A", Arrays.asList(production2)));
        
        return new Grammar(nonterminals, terminals,
                           startSymbol, productions);
    }
    
    
    private static Grammar initGrammar7() {
        String[] array = new String[]{"E", "T", "F"};
        List<String> nonterminals = Arrays.asList(array);
        
        String[] tarray = new String[]{"+", "*", "(", ")", "id", "$"};
        List<String> terminals = Arrays.asList(tarray);
        
        String startSymbol = "E";
        
        ArrayList productions = new ArrayList();
        String[] production0 = new String[]{"E", "+", "T"};
        productions.add(new Rule("E", Arrays.asList(production0)));
        String[] production1 = new String[]{"T"};
        productions.add(new Rule("E", Arrays.asList(production1)));
        String[] production2 = new String[]{"T", "*", "F"};
        productions.add(new Rule("T", Arrays.asList(production2)));
        String[] production3 = new String[]{"F"};
        productions.add(new Rule("T", Arrays.asList(production3)));
        String[] production4 = new String[]{"(", "E", ")"};
        productions.add(new Rule("F", Arrays.asList(production4)));
        String[] production5 = new String[]{"id"};
        productions.add(new Rule("F", Arrays.asList(production5)));
        
        return new Grammar(nonterminals, terminals, startSymbol, productions);
    }
    
    private static String toTex(Grammar grammar) {
        GrammarAnalyzer ga = new GrammarAnalyzer(grammar);
        ILL1ParsingTable table = ga.getTable();
        
        StringBuilder sb = new StringBuilder();
        sb = toTex(grammar, sb);
        sb = toTex(grammar, ga, sb);
        sb = toTex(table, sb);
        return sb.toString();
    }
    
    private static StringBuilder toTex(Grammar grammar, StringBuilder sb) {
        sb.append("Grammatik G=(N,T,P,S):\\\\ \n");
        sb.append("Startsymbol S: "+grammar.getStart()+" \\\\ \n");
        sb.append("Nichtterminalen N: \\{");
        for(int i = 0; i < grammar.getNonterminals().size(); i++) {
            String nonterminal = grammar.getNonterminals().get(i);
            sb.append(nonterminal);
            if(i<grammar.getNonterminals().size()-1) {
                sb.append(", ");
            }
        }
        sb.append("\\} \\\\ \n");
        sb.append("Terminalen T: \\{");
        for(int i = 0; i < grammar.getTerminals().size(); i++) {
            String terminal = grammar.getTerminals().get(i);
            if("$".equals(terminal)) {
                sb.append("\\$");
            } else {
                sb.append(terminal);
            }
            if(i<grammar.getTerminals().size()-1) {
                sb.append(", ");
            }
        }
        sb.append("\\} \\\\ \n");
        sb.append("Produktionen P: \\{ \\\\ \n");
        for(Rule rule: grammar.getProductions()) {
            sb.append("$");
            sb.append(rule.getNonterminal());
            sb.append(" \\rightarrow ");
            if(rule.getProduction().isEmpty()) {
                sb.append(" \\epsilon ");
            } else {
                for(int i = 0; i < rule.getProduction().size(); i++) {
                    sb.append(rule.getProduction().get(i));
                }
            }
            sb.append("$");
            sb.append("\\\\ \n");
            
        }
        sb.append("\\} \\\\ \n\n");
        return sb;
    }
    
    private static StringBuilder toTex(Grammar grammar, GrammarAnalyzer ga, StringBuilder sb) {
        Set<String> nullable = ga.getNullable();
        sb.append("Nullable=\\{");
        int i = 0;
        for(String nonterminal: nullable) {
            sb.append(nonterminal);
            if(i<nullable.size()-1) {
                sb.append(", ");
            }
            i++;
        }
        sb.append("\\} \\\\ \n");
        
        Map<String, Set<String>> first = ga.getFirst();
        sb.append("First:\\\\ \n");
        for(String nonterminal: grammar.getNonterminals()) {
            sb.append("FIRST(");
            sb.append(nonterminal);
            sb.append(")=\\{");
            Set<String> firstSet = first.get(nonterminal);
            i=0;
            for(String f: firstSet) {
                sb.append(f);
                i++;
                if(i<firstSet.size()) {
                    sb.append(", ");
                }
            }
            sb.append("\\} \\\\ \n");
        }
        sb.append("\n");
        
        Map<String, Set<String>> follow = ga.getFollow();
        sb.append("Follow:\\\\ \n");
        for(String nonterminal: grammar.getNonterminals()) {
            sb.append("FOLLOW(");
            sb.append(nonterminal);
            sb.append(")=\\{");
            Set<String> followSet = follow.get(nonterminal);
            i=0;
            for(String f: followSet) {
                if("$".equals(f)) {
                    sb.append("\\$");
                } else {
                    sb.append(f);
                }
                i++;
                if(i<followSet.size()) {
                    sb.append(", ");
                }
            }
            sb.append("\\} \\\\ \n");
        }
        sb.append("\n");
        return sb;
    }
    

    private static StringBuilder toTex(ILL1ParsingTable table, StringBuilder sb) {
        sb.append("Parsingtabelle:\\\\ \n");
        sb.append("\\begin{adjustbox}{max width=1.5\\textwidth, center}\n");
        sb.append("\\begin{tabular}{");
        // compute table header
        List<String> terminals = table.getTerminals();
        for(int i = 0; i < terminals.size()+1; i++) {
            sb.append("| c ");
        }
        
        sb.append("|}\n \\hline \n &");
        for(int i = 0; i < terminals.size(); i++) {
            String terminal = terminals.get(i);
            if("$".equals(terminal)) {
                sb.append("\\$");
            } else {
                sb.append(terminal);
            }
            if(i<terminals.size()-1) {
               sb.append(" & ");
            }
        }
        sb.append("\\\\ \\hline \n");
        
        // compute rows
        List<String> nonterminals = table.getNonterminals();
        for(String nonterminal: nonterminals) {
            sb.append(nonterminal);
            sb.append(" & ");
            for(int i = 0; i < terminals.size(); i++) {
                String terminal = terminals.get(i);
                List<String> production = table.get(nonterminal, terminal);
                if(production!=null) {
                    if(production.isEmpty()) {
                        sb.append("$\\epsilon$");
                    } else {
                        for(String symbol:production) {
                            sb.append(symbol);
                        }
                    }
                }
                if(i<terminals.size()-1) {
                    sb.append(" & ");
                }
            }
            sb.append("\\\\ \\hline \n");
        }
        sb.append("\\end{tabular}\n");
        sb.append("\\end{adjustbox}\n\n");
        return sb;
    }
}
