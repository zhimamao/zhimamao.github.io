/* libhello.c - demonstrate library use. */

#include <stdio.h>

void hello(char *msg) {
   printf("libHello: %s\n", msg);
}

