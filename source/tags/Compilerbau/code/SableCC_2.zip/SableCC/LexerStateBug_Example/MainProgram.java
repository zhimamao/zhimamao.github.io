import java.io.IOException;
import java.io.PushbackReader;
import java.io.StringReader;

import lexer.Lexer;
import lexer.LexerException;
import node.EOF;
import node.Token;

public class MainProgram {

	public static void main(String[] args) throws LexerException, IOException {

		String input = "do ** do **";

		StringReader reader = new StringReader(input);
		PushbackReader r = new PushbackReader(reader);
		Lexer l = new Lexer(r);

		Token t;
		do {
			t = l.next();
			System.out.print(t.getClass().getSimpleName());
			System.out.print(" ");
		} while (!(t instanceof EOF));

	}

}
