import java.io.IOException;
import java.io.PushbackReader;
import java.io.StringReader;

import parser.Parser;
import parser.ParserException;

import lexer.Lexer;
import lexer.LexerException;
import node.Start;


public class MainProgram {


	public static void main(String[] args) throws 
			LexerException, IOException, ParserException {
		parse(args[0]);
	}

	private static void parse(String input) throws ParserException,
			LexerException, IOException {
		StringReader reader = new StringReader("(30+5)*2");
		PushbackReader r = new PushbackReader(reader, 100);
		Lexer l = new Lexer(r);
		Parser parser = new Parser(l);
		Start start = parser.parse();
		Calculator calculator = new Calculator();
		start.apply(calculator);
		System.out.println(calculator.result);
	}

}
