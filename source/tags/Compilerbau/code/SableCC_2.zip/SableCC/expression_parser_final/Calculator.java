import node.AAddExpr;
import node.AMultExpr;
import node.ANumberExpr;
import analysis.DepthFirstAdapter;


public class Calculator extends DepthFirstAdapter {
	
	public int result;

	@Override
	public void caseAAddExpr(AAddExpr node) {
		Calculator left = new Calculator();
		node.getLeft().apply(left);
		Calculator right = new Calculator();
	    node.getRight().apply(right);
	    result = left.result + right.result;
	}
	
	@Override
	public void caseAMultExpr(AMultExpr node) {
		Calculator left = new Calculator();
		node.getLeft().apply(left);
		Calculator right = new Calculator();
	    node.getRight().apply(right);
	    result = left.result * right.result;
	}
	

	
	@Override
	public void outANumberExpr(ANumberExpr node) {
	  result = Integer.parseInt(node.getNumber().getText());
	}

}
