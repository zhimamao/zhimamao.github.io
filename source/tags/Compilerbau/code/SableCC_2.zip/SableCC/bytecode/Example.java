public class Example
{
	public static void main(String args[])
	{
	   int x = 1;
	   int y = 7;
	   int z = 3;
	   System.out.println((x+y)*z);
	}
}
