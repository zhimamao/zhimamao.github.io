import analysis.DepthFirstAdapter;
import node.*;

public class CodeGen extends DepthFirstAdapter
{
    public String code = "";
    
    public void outAAnumberAexpr(AAnumberAexpr node)
    {
    	String number = node.getNumber().toString();
        code += "\tldc " + number + "\n";
    }
    
    public void outAAmodAexpr(AAmodAexpr node)
    {
        code +="\tirem\n";
    }
    
    public void outAAmultAexpr(AAmultAexpr node)
    {
        code +="\timul\n";
    }
    
    public void outAAdivAexpr(AAdivAexpr node)
    {
        code +="\tidiv\n";
    }
    
    public void outAAplusAexpr(AAplusAexpr node)
    {
        code +="\tiadd\n";
    }
    
    public void outAAminusAexpr(AAminusAexpr node)
    {
        
        code +="\tisub\n";
    }
}