import java.io.IOException;
import java.io.PushbackReader;
import java.io.StringReader;

import parser.Parser;
import parser.ParserException;

import lexer.Lexer;
import lexer.LexerException;
import node.Start;
import node.Token;

public class MainProgram {


	public static void main(String[] args) throws 
			LexerException, IOException, ParserException {
//		parse("test");
//      parse("1+");
		parse("33+7*(5+1)");
	}

	private static void parse(String input) throws ParserException,
			LexerException, IOException {
		StringReader reader = new StringReader(input);
		PushbackReader r = new PushbackReader(reader, 100);
		Lexer l = new Lexer(r);
		Parser parser = new Parser(l);
		Start start = parser.parse();
		ASTPrinter printer = new ASTPrinter();
		start.apply(printer);
	}

}
