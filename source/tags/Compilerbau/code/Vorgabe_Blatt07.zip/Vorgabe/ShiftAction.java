//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

public class ShiftAction implements IParseAction {
    private LR0Node node;

    public ShiftAction(LR0Node node) {
        this.node = node;
    }

    public ActionType getType() {
        return ActionType.SHIFT;
    }

    public LR0Node getNode() {
        return this.node;
    }

    public String toString() {
        return "shift " + this.node.getNumber() + " ";
    }
}
