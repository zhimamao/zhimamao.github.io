import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class LR0Node {
    private Set<LR0Item> items;
    private Set<LREdge> edges;
    private int nodeNumber;

    public LR0Node(Set<LR0Item> items, int nodeNumber) {
        this.items = items;
        this.edges = new HashSet();
        this.nodeNumber = nodeNumber;
    }

    public Set<LR0Item> getItems() {
        return this.items;
    }

    public Set<LREdge> getEdges() {
        return this.edges;
    }

    public int getNumber() {
        return this.nodeNumber;
    }

    public void addEdge(LREdge edge) {
        this.edges.add(edge);
    }

    public Set<LR0Item> getReduceItems() {
        HashSet reduceItems = new HashSet();

        for(LR0Item item: items)
            if(item.isDotAtEnd())
                reduceItems.add(item);

        return reduceItems;
    }
}
