public class LREdge {
    private LR0Node start;
    private String symbol;
    private LR0Node end;

    public LREdge(LR0Node start, String symbol, LR0Node end) {
        this.start = start;
        this.symbol = symbol;
        this.end = end;
    }

    public LR0Node getStart() {
        return this.start;
    }

    public String getSymbol() {
        return this.symbol;
    }

    public LR0Node getEnd() {
        return this.end;
    }
}
