public class AcceptAction implements IParseAction {
    public AcceptAction() {
    }

    public ActionType getType() {
        return ActionType.ACCEPT;
    }

    public String toString() {
        return "accept";
    }
}
