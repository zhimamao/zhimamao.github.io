import java.util.Set;

public interface ILR0Automaton {
    Set<LR0Item> closure(Set<LR0Item> items);

    Set<LR0Item> gotoState(Set<LR0Item> items, String symbol);

    Set<LR0Node> getStates();

    String getNewStartSymbol();

    Grammar getGrammar();
}
