public interface IParseAction {
    ActionType getType();
}
