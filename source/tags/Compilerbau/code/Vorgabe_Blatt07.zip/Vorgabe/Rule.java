import java.util.List;

public class Rule
{
    private String nonterminal;
    private List<String> production;
    
    public Rule(String nonterminal, List<String> production)
    {
        this.nonterminal = nonterminal;
        this.production  = production;
    }
    
    public String getNonterminal()
    {
        return nonterminal;
    }
    
    public List<String> getProduction()
    {
        return production;
    }

    // TODO :-)
    public int hashCode()
    {
        int hash = nonterminal.hashCode();
        for(String s: production)
            hash += s.hashCode();
        return hash;
    }
    
    public boolean equals(Object o)
    {
        if(o==this)
            return true;
        
        if(o==null)
            return false;
        
        if(o.getClass()==this.getClass()) {
            Rule other = (Rule) o;
            if(!other.getNonterminal().equals(this.nonterminal))
                return false;
            if(!other.getProduction().equals(this.production))
                return false;
            return true;
        }
        return false;
    }
    
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(this.nonterminal);
        sb.append("->");
        
        for(String s: production)
            sb.append(" " + s);
        
        return sb.toString();
    }
    
}