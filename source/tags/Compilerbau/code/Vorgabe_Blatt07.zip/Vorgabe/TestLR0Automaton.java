// javac -cp .:junit-4.12.jar:hamcrest-core-1.3.jar TestLR0Automaton.java
// java -cp .:junit-4.12.jar:hamcrest-core-1.3.jar org.junit.runner.JUnitCore TestLR0Automaton

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;

import junit.framework.TestCase;

import org.junit.Test;
import org.junit.Before;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Map;
import java.util.List;
import java.util.Set;


public class TestLR0Automaton extends TestCase {
    
    private Grammar grammar0;
    private Grammar grammar1;
    private Grammar grammar2;
    private Grammar grammar3;
    private Grammar grammar4;
    private Grammar grammar5;
    private Grammar grammar6;
    private Grammar grammar7;
    
    
    @Before
    public void setUp()
    {
        grammar0 = initGrammar0();
        grammar1 = initGrammar1();
        grammar2 = initGrammar2();
        grammar3 = initGrammar3();
        grammar4 = initGrammar4();
        grammar5 = initGrammar5();
        grammar6 = initGrammar6();
        grammar7 = initGrammar7();
    }
    
    private Grammar initGrammar0()
    {
        /*
         Z -> d
         Z -> X Y Z
         Y ->
         Y -> c
         X -> Y
         X -> a
         
         */
        
        String narray[] = {"X", "Y", "Z"};
        List<String> nonterminals = Arrays.asList(narray);
        
        String tarray[] = {"a","c","d","$"};
        List<String> terminals = Arrays.asList(tarray);
        
        String startSymbol = "Z";
        List<Rule> productions = new ArrayList<Rule>();
        String production0[] = {"d"};
        productions.add(new Rule("Z", Arrays.asList(production0)));
        String production1[] = {"X", "Y", "Z"};
        productions.add(new Rule("Z", Arrays.asList(production1)));
        productions.add(new Rule("Y", Collections.emptyList()));
        String production2[] = {"c"};
        productions.add(new Rule("Y", Arrays.asList(production2)));
        String production3[] = {"Y"};
        productions.add(new Rule("X", Arrays.asList(production3)));
        String production4[] = {"a"};
        productions.add(new Rule("X", Arrays.asList(production4)));
        
        return new Grammar(nonterminals, terminals,
                           startSymbol, productions);
    }
    
    
    private Grammar initGrammar1()
    {
        /*
         E  -> T E'
         E' -> + T E'
         E' ->
         T  -> F T'
         T' -> * F T'
         T' ->
         F  -> ( E )
         F  -> id
         
         */
        
        String narray[] = {"E", "E'", "T", "T'", "F"};
        List<String> nonterminals = Arrays.asList(narray);
        
        String tarray[] = {"+","*","(",")","id", "$"};
        List<String> terminals = Arrays.asList(tarray);
        
        String startSymbol = "E";
        List<Rule> productions = new ArrayList<Rule>();
        String production0[] = {"T", "E'"};
        productions.add(new Rule("E", Arrays.asList(production0)));
        String production1[] = {"+", "T", "E'"};
        productions.add(new Rule("E'", Arrays.asList(production1)));
        productions.add(new Rule("E'", Collections.emptyList()));
        String production2[] = {"F", "T'"};
        productions.add(new Rule("T", Arrays.asList(production2)));
        String production3[] = {"*", "F", "T'"};
        productions.add(new Rule("T'", Arrays.asList(production3)));
        productions.add(new Rule("T'", Collections.emptyList()));
        String production4[] = {"(", "E", ")"};
        productions.add(new Rule("F", Arrays.asList(production4)));
        String production5[] = {"id"};
        productions.add(new Rule("F", Arrays.asList(production5)));
        
        return new Grammar(nonterminals, terminals,
                           startSymbol, productions);
    }
    
    private Grammar initGrammar2()
    {
        /*
         S  -> [ A ]
         S  -> [ ]
         S  -> a
         A  -> A , S
         A  -> S
         */
        
        String narray[] = {"S", "A"};
        List<String> nonterminals = Arrays.asList(narray);
        
        String tarray[] = {"[","]","a",",", "$"};
        List<String> terminals = Arrays.asList(tarray);
        
        String startSymbol = "S";
        List<Rule> productions = new ArrayList<Rule>();
        String production0[] = {"[", "A", "]"};
        productions.add(new Rule("S", Arrays.asList(production0)));
        String production1[] = {"[", "]"};
        productions.add(new Rule("S", Arrays.asList(production1)));
        String production2[] = {"a"};
        productions.add(new Rule("S", Arrays.asList(production2)));
        String production3[] = {"A", ",", "S"};
        productions.add(new Rule("A", Arrays.asList(production3)));
        String production4[] = {"S"};
        productions.add(new Rule("A", Arrays.asList(production4)));
        
        return new Grammar(nonterminals, terminals,
                           startSymbol, productions);
    }
    
    private Grammar initGrammar3()
    {
        /*
         S -> S + S
         S -> S S
         S -> ( S )
         S -> S *
         S -> a
         */
        
        String narray[] = {"S"};
        List<String> nonterminals = Arrays.asList(narray);
        
        String tarray[] = {"+","(",")","*", "a", "$"};
        List<String> terminals = Arrays.asList(tarray);
        
        String startSymbol = "S";
        List<Rule> productions = new ArrayList<Rule>();
        String production0[] = {"S", "+", "S"};
        productions.add(new Rule("S", Arrays.asList(production0)));
        String production1[] = {"S", "S"};
        productions.add(new Rule("S", Arrays.asList(production1)));
        String production2[] = {"(", "S", ")"};
        productions.add(new Rule("S", Arrays.asList(production2)));
        String production3[] = {"S", "*"};
        productions.add(new Rule("S", Arrays.asList(production3)));
        String production4[] = {"a"};
        productions.add(new Rule("S", Arrays.asList(production4)));
        
        return new Grammar(nonterminals, terminals,
                           startSymbol, productions);
    }
    
    
    private Grammar initGrammar4()
    {
        /*
         S -> ( L )
         S -> a
         L -> L , S
         L -> S
         */
        
        String narray[] = {"S", "L"};
        List<String> nonterminals = Arrays.asList(narray);
        
        String tarray[] = {"(",")",",", "a", "$"};
        List<String> terminals = Arrays.asList(tarray);
        
        String startSymbol = "S";
        List<Rule> productions = new ArrayList<Rule>();
        String production0[] = {"(", "L", ")"};
        productions.add(new Rule("S", Arrays.asList(production0)));
        String production1[] = {"a"};
        productions.add(new Rule("S", Arrays.asList(production1)));
        String production2[] = {"L", ",", "S"};
        productions.add(new Rule("L", Arrays.asList(production2)));
        String production3[] = {"S"};
        productions.add(new Rule("L", Arrays.asList(production3)));
        
        
        return new Grammar(nonterminals, terminals,
                           startSymbol, productions);
    }
    
    
    private Grammar initGrammar5()
    {
        /*
         S -> 0 S
         S -> S 1
         S -> 1 0
         */
        
        String narray[] = {"S"};
        List<String> nonterminals = Arrays.asList(narray);
        
        String tarray[] = {"0","1", "$"};
        List<String> terminals = Arrays.asList(tarray);
        
        String startSymbol = "S";
        List<Rule> productions = new ArrayList<Rule>();
        String production0[] = {"0", "S"};
        productions.add(new Rule("S", Arrays.asList(production0)));
        String production1[] = {"S", "1"};
        productions.add(new Rule("S", Arrays.asList(production1)));
        String production2[] = {"1", "0"};
        productions.add(new Rule("S", Arrays.asList(production2)));
        
        return new Grammar(nonterminals, terminals,
                           startSymbol, productions);
    }
    
    
    private Grammar initGrammar6()
    {
        /*
         S -> S A
         S -> A
         A -> a
         */
        
        String narray[] = {"S", "A"};
        List<String> nonterminals = Arrays.asList(narray);
        
        String tarray[] = {"a", "$"};
        List<String> terminals = Arrays.asList(tarray);
        
        String startSymbol = "S";
        List<Rule> productions = new ArrayList<Rule>();
        String production0[] = {"S", "A"};
        productions.add(new Rule("S", Arrays.asList(production0)));
        String production1[] = {"A"};
        productions.add(new Rule("S", Arrays.asList(production1)));
        String production2[] = {"a"};
        productions.add(new Rule("A", Arrays.asList(production2)));
        
        return new Grammar(nonterminals, terminals,
                           startSymbol, productions);
    }
    

    private Grammar initGrammar7() {
        String[] array = new String[]{"E", "T", "F"};
        List<String> nonterminals = Arrays.asList(array);

        String[] tarray = new String[]{"+", "*", "(", ")", "id", "$"};
        List<String> terminals = Arrays.asList(tarray);
        
        String startSymbol = "E";
        
        ArrayList productions = new ArrayList();
        String[] production0 = new String[]{"E", "+", "T"};
        productions.add(new Rule("E", Arrays.asList(production0)));
        String[] production1 = new String[]{"T"};
        productions.add(new Rule("E", Arrays.asList(production1)));
        String[] production2 = new String[]{"T", "*", "F"};
        productions.add(new Rule("T", Arrays.asList(production2)));
        String[] production3 = new String[]{"F"};
        productions.add(new Rule("T", Arrays.asList(production3)));
        String[] production4 = new String[]{"(", "E", ")"};
        productions.add(new Rule("F", Arrays.asList(production4)));
        String[] production5 = new String[]{"id"};
        productions.add(new Rule("F", Arrays.asList(production5)));
        
        return new Grammar(nonterminals, terminals, startSymbol, productions);
    }
    
    @Test
    public void testItemCompare()
    {
        String production0[] = {"d"};
        Rule rule0 = new Rule("Z", Arrays.asList(production0));
        LR0Item item0 = new LR0Item(rule0, 0); // Z->.d
        String production1[] = {"d"};
        Rule rule1 = new Rule("Z", Arrays.asList(production0));
        LR0Item item1 = new LR0Item(rule1, 0); // Z->.d
        Rule rule2 = new Rule("Z", Arrays.asList(production0));
        LR0Item item2 = new LR0Item(rule2, 1); // Z->d.
        assertTrue(item0.equals(item1));
        assertFalse(item0.equals(item2));
        
        Set<LR0Item> itemSet0 = new HashSet<LR0Item>();
        itemSet0.add(item0);
        itemSet0.add(item2);
        Set<LR0Item> itemSet1 = new HashSet<LR0Item>();
        itemSet1.add(item1);
        itemSet1.add(item2);
        Set<LR0Item> itemSet2 = new HashSet<LR0Item>();
        itemSet2.add(item0);
        itemSet2.add(item1);
        Set<LR0Item> itemSet3 = new HashSet<LR0Item>();
        itemSet3.add(item2);
        itemSet3.add(item1);
        assertTrue(itemSet0.equals(itemSet1));
        assertFalse(itemSet0.equals(itemSet2));
        assertTrue(itemSet0.equals(itemSet3));
    }
    
    @Test
    public void testClosure()
    {
        /*
         
         Z -> d
         Z -> X Y Z
         Y ->
         Y -> c
         X -> Y
         X -> a
         
         */
        
        LR0Automaton automaton = new LR0Automaton(grammar0);
        
        String production0[] = {"Z", "$"};
        LR0Item item0 = new LR0Item(new Rule("Z'", Arrays.asList(production0)), 0); // Z'->.Z$
        String production1[] = {"d"};
        LR0Item item1 = new LR0Item(new Rule("Z", Arrays.asList(production1)), 0); // Z->.d
        String production2[] = {"X", "Y", "Z"};
        LR0Item item2 = new LR0Item(new Rule("Z", Arrays.asList(production2)), 0); // Z->.XYZ
        String production3[] = {"Y"};
        LR0Item item3 = new LR0Item(new Rule("X", Arrays.asList(production3)), 0); // X->.Y
        String production4[] = {"a"};
        LR0Item item4 = new LR0Item(new Rule("X", Arrays.asList(production4)), 0); // X->.a
        String production5[] = {"c"};
        LR0Item item5 = new LR0Item(new Rule("Y", Arrays.asList(production5)), 0); // Y->.c
        LR0Item item6 = new LR0Item(new Rule("Y", Collections.emptyList()),0);     // Y->.
        LR0Item item7 = new LR0Item(new Rule("Z", Arrays.asList(production2)), 1); // Z->X.YZ
        LR0Item item8 = new LR0Item(new Rule("Z", Arrays.asList(production2)), 2); // Z->XY.Z
        LR0Item item9 = new LR0Item(new Rule("Z", Arrays.asList(production2)), 3); // Z->XYZ.
        LR0Item item10 = new LR0Item(new Rule("Z'", Arrays.asList(production0)), 1); // Z'->Z.$
        LR0Item item11 = new LR0Item(new Rule("Z", Arrays.asList(production1)), 1); // Z->d.
        LR0Item item12 = new LR0Item(new Rule("X", Arrays.asList(production3)), 1); // X->Y.
        
        Set<LR0Item> itemSet0 = new HashSet<LR0Item>();
        itemSet0.add(item1);
        Set<LR0Item> result = automaton.closure(itemSet0);
        assertTrue(result.contains(item1));
        assertEquals(1, result.size());
        
        Set<LR0Item> itemSet1 = new HashSet<LR0Item>();
        itemSet1.add(item2);
        result = automaton.closure(itemSet1);
        assertTrue(result.contains(item2));
        assertTrue(result.contains(item3));
        assertTrue(result.contains(item4));
        assertTrue(result.contains(item5));
        assertTrue(result.contains(item6));
        assertEquals(5, result.size());
        
        Set<LR0Item> itemSet3 = new HashSet<LR0Item>();
        itemSet3.add(item0);
        result = automaton.closure(itemSet3);
        assertTrue(result.contains(item0));
        assertTrue(result.contains(item1));
        assertTrue(result.contains(item2));
        assertTrue(result.contains(item3));
        assertTrue(result.contains(item4));
        assertTrue(result.contains(item5));
        assertTrue(result.contains(item6));
        assertEquals(7, result.size());
        
        Set<LR0Item> itemSet4 = new HashSet<LR0Item>();
        itemSet4.add(item7);
        result = automaton.closure(itemSet4);
        assertTrue(result.contains(item7));
        assertTrue(result.contains(item5));
        assertTrue(result.contains(item6));
        assertEquals(3, result.size());
        
        Set<LR0Item> itemSet5 = new HashSet<LR0Item>();
        itemSet5.add(item8);
        result = automaton.closure(itemSet5);
        assertTrue(result.contains(item8));
        assertTrue(result.contains(item1));
        assertTrue(result.contains(item2));
        assertTrue(result.contains(item3));
        assertTrue(result.contains(item4));
        assertTrue(result.contains(item5));
        assertTrue(result.contains(item6));
        assertEquals(7, result.size());
        
        Set<LR0Item> itemSet6 = new HashSet<LR0Item>();
        itemSet6.add(item9);
        result = automaton.closure(itemSet6);
        assertTrue(result.contains(item9));
        assertEquals(1, result.size());
        
        Set<LR0Item> itemSet7 = new HashSet<LR0Item>();
        itemSet7.add(item10);
        result = automaton.closure(itemSet7);
        assertTrue(result.contains(item10));
        assertEquals(1, result.size());
        
        Set<LR0Item> itemSet8 = new HashSet<LR0Item>();
        itemSet8.add(item11);
        result = automaton.closure(itemSet8);
        assertTrue(result.contains(item11));
        assertEquals(1, result.size());
        
        Set<LR0Item> itemSet9 = new HashSet<LR0Item>();
        itemSet9.add(item12);
        result = automaton.closure(itemSet9);
        assertTrue(result.contains(item12));
        assertEquals(1, result.size());
    }
    
    @Test
    public void testGoto()
    {
        /*
         
         Z -> d
         Z -> X Y Z
         Y ->
         Y -> c
         X -> Y
         X -> a
         
         */
        
        LR0Automaton automaton = new LR0Automaton(grammar0);
        
        String production0[] = {"Z", "$"};
        LR0Item item0 = new LR0Item(new Rule("Z'", Arrays.asList(production0)), 0); // Z'->.Z$
        String production1[] = {"d"};
        LR0Item item1 = new LR0Item(new Rule("Z", Arrays.asList(production1)), 0); // Z->.d
        String production2[] = {"X", "Y", "Z"};
        LR0Item item2 = new LR0Item(new Rule("Z", Arrays.asList(production2)), 0); // Z->.XYZ
        String production3[] = {"Y"};
        LR0Item item3 = new LR0Item(new Rule("X", Arrays.asList(production3)), 0); // X->.Y
        String production4[] = {"a"};
        LR0Item item4 = new LR0Item(new Rule("X", Arrays.asList(production4)), 0); // X->.a
        String production5[] = {"c"};
        LR0Item item5 = new LR0Item(new Rule("Y", Arrays.asList(production5)), 0); // Y->.c
        LR0Item item6 = new LR0Item(new Rule("Y", Collections.emptyList()),0);     // Y->.
        LR0Item item7 = new LR0Item(new Rule("Z", Arrays.asList(production2)), 1); // Z->X.YZ
        LR0Item item8 = new LR0Item(new Rule("Z", Arrays.asList(production2)), 2); // Z->XY.Z
        LR0Item item9 = new LR0Item(new Rule("Z", Arrays.asList(production2)), 3); // Z->XYZ.
        LR0Item item10 = new LR0Item(new Rule("Z'", Arrays.asList(production0)), 1); // Z'->Z.$
        LR0Item item11 = new LR0Item(new Rule("Z", Arrays.asList(production1)), 1);  // Z->d.
        LR0Item item12 = new LR0Item(new Rule("X", Arrays.asList(production3)), 1);  // X->Y.
        LR0Item item13 = new LR0Item(new Rule("Z'", Arrays.asList(production0)), 1); // Z'->Z.$
        LR0Item item14 = new LR0Item(new Rule("Y", Arrays.asList(production5)), 1);  // Y->c.
        LR0Item item15 = new LR0Item(new Rule("X", Arrays.asList(production4)), 1);  // X->a.
        
        Set<LR0Item> itemSet0 = new HashSet<LR0Item>();
        itemSet0.add(item0);
        Set<LR0Item> itemSet1 = automaton.closure(itemSet0);
        assertTrue(itemSet1.contains(item0));
        assertTrue(itemSet1.contains(item1));
        assertTrue(itemSet1.contains(item2));
        assertTrue(itemSet1.contains(item3));
        assertTrue(itemSet1.contains(item4));
        assertTrue(itemSet1.contains(item5));
        assertTrue(itemSet1.contains(item6));
        assertEquals(7, itemSet1.size());
        
        Set<LR0Item> itemSet2 = automaton.gotoState(itemSet1, "Z");
        assertTrue(itemSet2.contains(item13));
        assertEquals(1, itemSet2.size());
        
        Set<LR0Item> itemSet3 = automaton.gotoState(itemSet1, "c");
        assertTrue(itemSet3.contains(item14));
        assertEquals(1, itemSet3.size());
        
        Set<LR0Item> itemSet4 = automaton.gotoState(itemSet1, "a");
        assertTrue(itemSet4.contains(item15));
        assertEquals(1, itemSet4.size());
        
        Set<LR0Item> itemSet5 = automaton.gotoState(itemSet1, "d");
        assertTrue(itemSet5.contains(item11));
        assertEquals(1, itemSet5.size());
        
        Set<LR0Item> itemSet6 = automaton.gotoState(itemSet1, "X");
        assertTrue(itemSet6.contains(item5));
        assertTrue(itemSet6.contains(item6));
        assertTrue(itemSet6.contains(item7));
        assertEquals(3, itemSet6.size());
        
        Set<LR0Item> itemSet7 = automaton.gotoState(itemSet6, "c");
        assertTrue(itemSet7.contains(item14));
        assertEquals(1, itemSet7.size());
        assertEquals(itemSet3, itemSet7);
        
        Set<LR0Item> itemSet8 = automaton.gotoState(itemSet6, "Y");
        assertTrue(itemSet8.contains(item8));
        assertTrue(itemSet8.contains(item1));
        assertTrue(itemSet8.contains(item2));
        assertTrue(itemSet8.contains(item3));
        assertTrue(itemSet8.contains(item4));
        assertTrue(itemSet8.contains(item5));
        assertTrue(itemSet8.contains(item6));
        assertEquals(7, itemSet8.size());
        
        Set<LR0Item> itemSet9 = automaton.gotoState(itemSet8, "Z");
        assertTrue(itemSet9.contains(item9));
        assertEquals(1, itemSet9.size());
        
        Set<LR0Item> itemSet10 = automaton.gotoState(itemSet8, "c");
        assertEquals(itemSet10, itemSet7);
        assertEquals(itemSet3, itemSet10);
        
        Set<LR0Item> itemSet11 = automaton.gotoState(itemSet8, "d");
        assertEquals(itemSet5, itemSet11);
        
        Set<LR0Item> itemSet12 = automaton.gotoState(itemSet8, "X");
        assertEquals(itemSet6, itemSet12);
        
        Set<LR0Item> itemSet13 = automaton.gotoState(itemSet8, "a");
        assertEquals(itemSet13, itemSet4);
        
    }

    @Test
    public void testPrintAutomaton() {
        LR0Automaton automaton = new LR0Automaton(this.grammar0);
        Set states = automaton.getStates();
        //System.out.println(ViewUtil.toDot(states));
    }

    @Test
    public void testPrintTable() {
        LR0Automaton automaton = new LR0Automaton(this.grammar0);
        LR0Table table = new LR0Table(automaton);
        //System.out.println(ViewUtil.toTex(table));
    }
    
    @Test
    public void testParser() {
        Grammar grammar = this.grammar7;
        LR0Automaton automaton = new LR0Automaton(grammar);
        GrammarAnalyzer ga = new GrammarAnalyzer(grammar);
        Map<String, Set<String>> follow = ga.getFollow();
        SLRTable table = new SLRTable(automaton, follow);
        Parser parser = new Parser(table);
        List<String> input = new ArrayList<String>();
        input.add("id");
        input.add("*");
        input.add("id");
        input.add("+");
        input.add("id");
        input.add("$");
        TreeNode root = parser.parse(input);
        System.out.println(ViewUtil.toDot(root));
        //printTree(root);
    }
    
    private void printTree(Node node)
    {
        List<Node> queue = new ArrayList<Node>();
        queue.add(node);
        while(!queue.isEmpty())
        {
            node = queue.remove(0);
            if(node.getNodes()!=null)
                queue.addAll(node.getNodes());
            System.out.println(node);
        }
    }
}
