
public class LR0Item {
    private int dot;
    private Rule rule;

    public LR0Item(Rule rule, int dot) {
        this.rule = rule;
        this.dot = dot;
    }

    public int getDot() {
        return this.dot;
    }

    public boolean isDotAtEnd() {
        return this.dot == this.rule.getProduction().size();
    }

    public String getSymbolAfterDot() {
        return (String)this.rule.getProduction().get(this.dot);
    }

    public Rule getRule() {
        return this.rule;
    }

    public int hashCode() {
        return this.rule.hashCode() + this.dot;
    }

    public boolean equals(Object other) {
        if(other == this) {
            return true;
        } else if(other == null) {
            return false;
        } else if(other.getClass() == this.getClass()) {
            LR0Item item = (LR0Item)other;
            return item.getDot() != this.dot?false:item.getRule().equals(this.rule);
        } else {
            return false;
        }
    }
}
