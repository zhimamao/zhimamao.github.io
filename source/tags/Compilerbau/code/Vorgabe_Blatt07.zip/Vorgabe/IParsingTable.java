import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public interface IParsingTable {
    Map<Entry<Integer, String>, List<IParseAction>> getTable();

    List<String> getTerminals();

    List<String> getNonterminals();

    int getStateNumber();
}
