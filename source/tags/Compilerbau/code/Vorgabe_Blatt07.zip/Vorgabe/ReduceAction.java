import java.util.Iterator;
import java.util.Set;

public class ReduceAction implements IParseAction {
    private Set<LR0Item> items;

    public ReduceAction(Set<LR0Item> items) {
        this.items = items;
    }

    public ActionType getType() {
        return ActionType.REDUCE;
    }

    public Set<LR0Item> getItems() {
        return this.items;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();

        for(LR0Item item: items) {
            sb.append("reduce ");
            sb.append(item.getRule().toString());
            sb.append(" \n");
        }

        return sb.toString();
    }
}
