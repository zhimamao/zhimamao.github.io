import java.util.List;

public class Grammar {
    private List<String> nonterminals;
    private List<String> terminals;
    private String start;
    private List<Rule> productions;

    public Grammar(List<String> nonterminals, List<String> terminals, String start, List<Rule> productions) {
        this.nonterminals = nonterminals;
        this.terminals = terminals;
        this.start = start;
        this.productions = productions;
    }

    public List<String> getNonterminals() {
        return this.nonterminals;
    }

    public List<String> getTerminals() {
        return this.terminals;
    }

    public boolean isNonterminal(String symbol) {
        return this.nonterminals.contains(symbol);
    }

    public boolean isTerminal(String symbol) {
        return this.terminals.contains(symbol);
    }

    public String getStart() {
        return this.start;
    }

    public List<Rule> getProductions() {
        return this.productions;
    }
}
