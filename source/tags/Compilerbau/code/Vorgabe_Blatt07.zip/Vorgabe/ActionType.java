public enum ActionType {
    SHIFT,
    REDUCE,
    ACCEPT,
    GOTO;

    private ActionType() {
    }
}
