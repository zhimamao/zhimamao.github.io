import java.util.List;

public class TreeNode {
    private String id;
    private List<TreeNode> nodes;
    
    public TreeNode(String id) {
        this.id = id;
    }
    
    public void setNodes(List<TreeNode> nodes)
    {
        this.nodes = nodes;
    }
    
    public List<TreeNode> getNodes()
    {
        return nodes;
    }
    
    public String toString()
    {
        return id;
    }
}