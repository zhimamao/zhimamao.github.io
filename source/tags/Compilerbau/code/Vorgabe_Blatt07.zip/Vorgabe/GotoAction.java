public class GotoAction implements IParseAction {
    private LR0Node node;

    public GotoAction(LR0Node node) {
        this.node = node;
    }

    public ActionType getType() {
        return ActionType.GOTO;
    }

    public LR0Node getNode() {
        return this.node;
    }

    public String toString() {
        return "goto " + this.node.getNumber();
    }
}
