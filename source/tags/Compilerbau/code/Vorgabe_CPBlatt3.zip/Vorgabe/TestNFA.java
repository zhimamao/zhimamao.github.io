// javac -cp .:junit-4.12.jar:hamcrest-core-1.3.jar TestNFA.java
// java -cp .:junit-4.12.jar:hamcrest-core-1.3.jar junit.textui.TestRunner TestNFA

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Test;

import junit.framework.TestCase;

public class TestNFA extends TestCase {

    @Test
    public void test01() {
        Set<Character> alphabet = new HashSet<Character>();
        alphabet.add('a');
        alphabet.add('b');

        Set<INode> nodes = new HashSet<INode>();
        Node n0 = new Node("0", false);
        Node n1 = new Node("1", false);
        Node n2 = new Node("2", false);
        Node n3 = new Node("3", true);
        nodes.add(n0);
        nodes.add(n1);
        nodes.add(n2);
        nodes.add(n3);

        Set<IEdge> edges = new HashSet<IEdge>();
        edges.add(new Edge(n0, 'a', n0));
        edges.add(new Edge(n0, 'a', n1));
        edges.add(new Edge(n0, 'b', n0));
        edges.add(new Edge(n1, 'b', n2));
        edges.add(new Edge(n2, 'b', n3));

        NFA nfa = new NFA(alphabet, nodes, n0, edges);

        assertTrue(n0.getNext('a').contains(n0));
        assertTrue(n0.getNext('a').contains(n1));
        assertEquals(2, n0.getNext('a').size());
        assertTrue(n0.getNext('b').contains(n0));
        assertEquals(1, n0.getNext('b').size());
        assertTrue(n1.getNext('b').contains(n2));
        assertEquals(1, n1.getNext('b').size());
        assertTrue(n2.getNext('b').contains(n3));
        assertEquals(1, n2.getNext('b').size());

        Set<List<INode>> allPaths = nfa.allPaths("abb");
        List<String> allPathStrings = new ArrayList<String>();
        for (List<INode> path : allPaths)
            allPathStrings.add(pathToString(path));
        assertEquals(2, allPaths.size());
        assertTrue(allPathStrings.contains("0000"));
        assertTrue(allPathStrings.contains("0123"));

        assertEquals("0123 akzeptieren", nfa.accept("abb"));
        assertEquals("00123 akzeptieren", nfa.accept("babb"));
        assertEquals("ablehnen", nfa.accept("bb"));
    }

    @Test
    public void test02() {
        Set<Character> alphabet = new HashSet<Character>();
        alphabet.add('a');
        alphabet.add('b');

        Set<INode> nodes = new HashSet<INode>();
        Node n0 = new Node("0", false);
        Node n1 = new Node("1", false);
        Node n2 = new Node("2", false);
        Node n3 = new Node("3", false);
        Node n4 = new Node("4", false);
        Node n5 = new Node("5", false);
        Node n6 = new Node("6", false);
        Node n7 = new Node("7", false);
        Node n8 = new Node("8", false);
        Node n9 = new Node("9", false);
        Node n10 = new Node("10", true);
        nodes.add(n0);
        nodes.add(n1);
        nodes.add(n2);
        nodes.add(n3);
        nodes.add(n4);
        nodes.add(n5);
        nodes.add(n6);
        nodes.add(n7);
        nodes.add(n8);
        nodes.add(n9);
        nodes.add(n10);

        Set<IEdge> edges = new HashSet<IEdge>();
        edges.add(new Edge(n0, '\0', n1));
        edges.add(new Edge(n0, '\0', n7));
        edges.add(new Edge(n1, '\0', n2));
        edges.add(new Edge(n1, '\0', n4));
        edges.add(new Edge(n2, 'a', n3));
        edges.add(new Edge(n4, 'b', n5));
        edges.add(new Edge(n3, '\0', n6));
        edges.add(new Edge(n5, '\0', n6));
        edges.add(new Edge(n6, '\0', n7));
        edges.add(new Edge(n6, '\0', n1));
        edges.add(new Edge(n7, 'a', n8));
        edges.add(new Edge(n8, 'b', n9));
        edges.add(new Edge(n9, 'b', n10));

        NFA nfa = new NFA(alphabet, nodes, n0, edges);
        Set<INode> eNodes = n0.epsilonClosure();
        assertEquals(5, eNodes.size());
        assertTrue(eNodes.contains(n0));
        assertTrue(eNodes.contains(n1));
        assertTrue(eNodes.contains(n7));
        assertTrue(eNodes.contains(n2));
        assertTrue(eNodes.contains(n4));
        eNodes = n1.epsilonClosure();
        assertEquals(3, eNodes.size());
        eNodes = n6.epsilonClosure();
        assertEquals(5, eNodes.size());

        assertTrue(nfa.accept("abb").contains("akzeptieren"));
        assertTrue(nfa.accept("bb").contains("ablehnen"));
        assertTrue(nfa.accept("babb").contains("akzeptieren"));
    }

    @Test
    public void test03() {
        Set<Character> alphabet = new HashSet<Character>();
        alphabet.add('a');
        alphabet.add('b');

        Set<INode> nodes = new HashSet<INode>();
        Node n0 = new Node("0", false);
        Node n1 = new Node("1", false);
        Node n2 = new Node("2", false);
        Node n3 = new Node("3", true);
        nodes.add(n0);
        nodes.add(n1);
        nodes.add(n2);
        nodes.add(n3);

        Set<IEdge> edges = new HashSet<IEdge>();
        edges.add(new Edge(n0, 'a', n0));
        edges.add(new Edge(n0, 'a', n1));
        edges.add(new Edge(n0, 'b', n0));
        edges.add(new Edge(n1, 'b', n2));
        edges.add(new Edge(n2, 'b', n3));

        NFA nfa = new NFA(alphabet, nodes, n0, edges);

        nfa.toDFA();
    }

    @Test
    public void test04() {
        Set<Character> alphabet = new HashSet<Character>();
        alphabet.add('a');
        alphabet.add('b');

        Set<INode> nodes = new HashSet<INode>();
        Node n0 = new Node("0", false);
        Node n1 = new Node("1", false);
        Node n2 = new Node("2", false);
        Node n3 = new Node("3", false);
        Node n4 = new Node("4", false);
        Node n5 = new Node("5", false);
        Node n6 = new Node("6", false);
        Node n7 = new Node("7", false);
        Node n8 = new Node("8", false);
        Node n9 = new Node("9", false);
        Node n10 = new Node("10", true);
        nodes.add(n0);
        nodes.add(n1);
        nodes.add(n2);
        nodes.add(n3);
        nodes.add(n4);
        nodes.add(n5);
        nodes.add(n6);
        nodes.add(n7);
        nodes.add(n8);
        nodes.add(n9);
        nodes.add(n10);

        Set<IEdge> edges = new HashSet<IEdge>();
        edges.add(new Edge(n0, '\0', n1));
        edges.add(new Edge(n0, '\0', n7));
        edges.add(new Edge(n1, '\0', n2));
        edges.add(new Edge(n1, '\0', n4));
        edges.add(new Edge(n2, 'a', n3));
        edges.add(new Edge(n4, 'b', n5));
        edges.add(new Edge(n3, '\0', n6));
        edges.add(new Edge(n5, '\0', n6));
        edges.add(new Edge(n6, '\0', n7));
        edges.add(new Edge(n6, '\0', n1));
        edges.add(new Edge(n7, 'a', n8));
        edges.add(new Edge(n8, 'b', n9));
        edges.add(new Edge(n9, 'b', n10));

        NFA nfa = new NFA(alphabet, nodes, n0, edges);

        nfa.toDFA();
    }

    private String pathToString(List<INode> path) {
        StringBuilder sb = new StringBuilder();
        for (INode node : path)
            sb.append(node.getName());
        return sb.toString();
    }

}
