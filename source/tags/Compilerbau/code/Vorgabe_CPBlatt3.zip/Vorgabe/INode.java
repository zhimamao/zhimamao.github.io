import java.util.Set;

public interface INode {
    public void addTransition(INode dest, char c);
    public Set<INode> getNext(char c);
    public String getName();
    public boolean isFinal();
    public Set<IEdge> getEdges();
    public Set<INode> epsilonClosure();
}
