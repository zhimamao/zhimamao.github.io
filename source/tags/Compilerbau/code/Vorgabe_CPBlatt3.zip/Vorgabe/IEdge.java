public interface IEdge {
    public INode getStart();
    public INode getEnd();
    public char getChar();
}