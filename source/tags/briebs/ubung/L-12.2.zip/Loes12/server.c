#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#include <errno.h>

#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>


#define BUFFER_SIZE 4096


int main(int argc, char** argv) {
	int sock, port;
	struct sockaddr_in saddr;


	if (argc < 2)
	{
		printf("Usage: server <port>\n");
		exit(EXIT_FAILURE);
	}

    port = atoi(argv[1]);

	// Erstelle einen neuen Socket: Stream socket mit TCP
	sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (sock == -1) {
		fprintf(stderr, "Opening socket failed: %s\n", strerror(errno));
		exit(EXIT_FAILURE);
	}
    // Erzeuge Socketadresse (beliebige IP-addr annehmen)
    memset( &saddr, 0, sizeof(saddr) );
    saddr.sin_family      = AF_INET;
    saddr.sin_addr.s_addr = htonl(INADDR_ANY);
    saddr.sin_port        = htons(port);

    // Binde den Socket
	if (bind(sock, (struct sockaddr*)&saddr, sizeof(saddr)) < 0) {
		fprintf(stderr, "Binding socket failed: %s\n", strerror(errno));
		close(sock);
		exit(EXIT_FAILURE);
	}

	if (listen(sock, 0) < 0) {
		fprintf(stderr, "Listening to socket failed: %s\n", strerror(errno));
		close(sock);
		exit(EXIT_FAILURE);
	}

	// Server loop
	while (1) {
		int sockConnection;
		struct sockaddr addrConnection;
		int addrlenConnection;
		char addrBuffer[64];
		int sent;
		int received;
		char buffer[BUFFER_SIZE];

		printf("Waiting for connections...\n");

		// Warte auf eingehende Verbindungen, blockierend
		sockConnection = accept(sock, &addrConnection, &addrlenConnection);
		if (sockConnection == -1) {
			fprintf(stderr, "Accepting connection failed: %s\n", strerror(errno));
			continue;
		}

		printf("%s connected\n", inet_ntop(AF_INET, &addrConnection, addrBuffer, sizeof(addrBuffer)));

		memset(buffer, 0, sizeof(buffer));
	
		// Hole Daten ab, blockierend
		received = recv(sockConnection, buffer, sizeof(buffer), 0);
		if (received < 0)
		{
			fprintf(stderr, "Receiving data failed: %s\n", strerror(errno));
			exit(EXIT_FAILURE);
		}	

		printf("Data received: %s\n", buffer);
      
		// Schicke Daten zurueck, echo
		sent = send(sockConnection, buffer, received, 0);
		if (sent < 0)
		{
			fprintf(stderr, "Sending data %s failed: %s\n", buffer, strerror(errno));
			exit(EXIT_FAILURE);
		}

		printf("Data sent. Closing connection.\n");

  	    // Blockiere jegliche weitere Uebertragungen
	    // und schliesse den Socket
	    shutdown(sockConnection, SHUT_RDWR);
	    close(sockConnection);
	}
   	
 	return 0;
}


