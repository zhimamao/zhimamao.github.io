/* Musterlösung zur Aufgabe 'Sockets'
 *
 * Schreiben Sie ein Program, welches mithilfe von Sockets einen Server und einen Client bereitstellt. Nach dem Setup
 * soll der Server in einer Endlosschleife auf eingehende Verbindungen warten. Die Adresse, sowie der Port des Servers
 * werden als Argumente über das Terminal bereitgestellt. Sobald eine Verbindung mit dem Server aufgebaut wurde,
 * empfängt dieser über seine aktive Verbindung Daten. Diese sollen in Form eines Echos wieder an den Sender
 * zurückgeschickt und die Verbindung mit ihm geschlossen werden.
 *
 * Der Client soll sich nach dem Setup mit einem Server verbinden, dessen Adresse und Port als Argumente vom Terminal
 * übergeben werden. Ein als Parameter übergebener String soll vom Client zum Server geschickt werden, sobald eine
 * gültige Verbindung mit dem Server aufgebaut wurde. Anschließend wartet der Client auf das Echo des Servers.
 * Client und Server können hier als zwei separate Programme implementiert werden. Es bietet sich aber an diese als
 * ein Program zu schreiben und mithilfe eines Arguments über das Terminal die jeweilige Funktion zu bestimmen.
 *
 * Hinweise:
 * - Lesen Sie sich die man-Pages zu den folgenden Funktionen durch: socket, shutdown, close, bind, listen, accept,
 *   connect, send, recv.
 * - Verwenden Sie TCP/IP-Sockets indem Sie SOCK_STREAM und IPPROTO_TCP als type und protocol an die Funktion socket
 *   übergeben.
 * - Die IP-Adresse sowie der Port müssen für die Struktur struct sockaddr passend umgewandelt werden.
 *   Hierzu bieten sich die folgenden Funktionen an: inet_addr, htons.
 * - Achten Sie allgemein darauf, Rückgabewerte auf mögliche Fehler zu überprüfen. Bei vielen Fehlern lässt sich die
 *   errno auslesen und per strerror in eine einfache lesbare Form umwandeln. Diese kann entweder, wie gewohnt, per
 *   printf oder mit fprintf auch auf den Stream stderr ausgegeben werden.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <errno.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>

#define BUFFER_SIZE 4096

int main(int argc, char** argv) {
	int sock, port;
	struct sockaddr_in saddr;


	if (argc < 2)
	{
		printf("Usage: server <port>\n");
		exit(EXIT_FAILURE);
	}

    port = atoi(argv[1]);

	// Erstelle einen neuen Socket: Stream socket mit TCP
	sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (sock == -1) {
		fprintf(stderr, "Opening socket failed: %s\n", strerror(errno));
		exit(EXIT_FAILURE);
	}
    // Erzeuge Socketadresse (beliebige IP-addr annehmen)
    memset( &saddr, 0, sizeof(saddr) );
    saddr.sin_family      = AF_INET;
    saddr.sin_addr.s_addr = htonl(INADDR_ANY);
    saddr.sin_port        = htons(port);

    // Binde den Socket
	if (bind(sock, (struct sockaddr*)&saddr, sizeof(saddr)) < 0) {
		fprintf(stderr, "Binding socket failed: %s\n", strerror(errno));
		close(sock);
		exit(EXIT_FAILURE);
	}

	if (listen(sock, 0) < 0) {
		fprintf(stderr, "Listening to socket failed: %s\n", strerror(errno));
		close(sock);
		exit(EXIT_FAILURE);
	}

	// Server loop
	while (1) {
		int sockConnection;
		struct sockaddr addrConnection;
		int addrlenConnection;
		char addrBuffer[64];
		int sent;
		int received;
		char buffer[BUFFER_SIZE];

		printf("Waiting for connections...\n");

		// Warte auf eingehende Verbindungen, blockierend
		sockConnection = accept(sock, &addrConnection, &addrlenConnection);
		if (sockConnection == -1) {
			fprintf(stderr, "Accepting connection failed: %s\n", strerror(errno));
			continue;
		}

		printf("%s connected\n", inet_ntop(AF_INET, &addrConnection, addrBuffer, sizeof(addrBuffer)));

		memset(buffer, 0, sizeof(buffer));
	
		// Hole Daten ab, blockierend
		received = recv(sockConnection, buffer, sizeof(buffer), 0);
		if (received < 0)
		{
			fprintf(stderr, "Receiving data failed: %s\n", strerror(errno));
			exit(EXIT_FAILURE);
		}	

		printf("Data received: %s\n", buffer);
      
		// Schicke Daten zurueck, echo
		sent = send(sockConnection, buffer, received, 0);
		if (sent < 0)
		{
			fprintf(stderr, "Sending data %s failed: %s\n", buffer, strerror(errno));
			exit(EXIT_FAILURE);
		}

		printf("Data sent. Closing connection.\n");

  	    // Blockiere jegliche weitere Uebertragungen
	    // und schliesse den Socket
	    shutdown(sockConnection, SHUT_RDWR);
	    close(sockConnection);
	}
   	
 	return 0;
}


