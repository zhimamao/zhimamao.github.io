#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#include <errno.h>

#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>


#define BUFFER_SIZE 4096


int main(int argc, char** argv) {
  	int sock;
	//struct sockaddr saddr;
	struct sockaddr_in saddr;
	int sent;
	int received;
	char addrBuffer[64];
	char buffer[BUFFER_SIZE];


	if (argc < 4) {
		printf("Usage: client <addr> <port> <string>\n");
		exit(EXIT_FAILURE);
	}

	// Erstelle einen neuen Socket: Stream socket mit TCP
	sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (sock == -1) {
		fprintf(stderr, "Opening socket failed: %s\n", strerror(errno));
		exit(EXIT_FAILURE);
	}

    // Adresse aufbauen
	saddr.sin_family      = AF_INET;
	saddr.sin_addr.s_addr = inet_addr(argv[1]);
	saddr.sin_port        = htons(atoi(argv[2]));

	// Typisches Muster Client: connect, dann send und/oder receive
	if (connect(sock, (struct sockaddr *) &saddr, sizeof(saddr)) < 0) {
		fprintf(stderr, "Connecting to %s failed: %s\n", argv[1], strerror(errno));
		exit(EXIT_FAILURE);
	}

	// Sende Daten an server, blockierend
	sent = send(sock, argv[3], strlen(argv[3]) + 1, 0);
	if (sent < 0) {
		fprintf(stderr, "Sending data %s failed: %s\n", argv[3], strerror(errno));
		exit(EXIT_FAILURE);
	}

	printf("Data sent to %s\n", inet_ntop(AF_INET, &saddr, addrBuffer, sizeof(addrBuffer)));

	memset(buffer, 0, sizeof(buffer));

	// Hole Daten, die vom Server kommen ab, blockierend
	received = recv(sock, buffer, sizeof(buffer), 0);
	if (received < 0) {
		fprintf(stderr, "Receiving data failed: %s\n", strerror(errno));
		exit(EXIT_FAILURE);
	}	

	printf("Data received: %s\n", buffer);

	// Blockiere jegliche weitere Uebertragungen
	// und schliesse den Socket
	shutdown(sock, SHUT_RDWR);
	close(sock);

	return 0;
}


