/* Musterlösung zur Aufgabe 'Verkettete Liste'
 *
 * In der Vorlesung wurde in Kapitel 3.4 (Double Pointers) eine einfach-verkettete Liste vorgestellt. An dieser Stelle
 * haben Sie gelernt, wie einzelne Elemente mithilfe von einfachen und doppelten Zeigern in der Liste gesucht und aus
 * der Liste entfernt werden können. In dieser Aufgabe sollen Sie nun selbst eine Liste für int-Werte implementieren.
 * Die Anzahl an hinzuzufügenden und zu entfernenden Elemente soll per Kommandozeile übergeben werden.
 *
 * a) Erstellen Sie eine struct list_node mit einem int value und einem Zeiger next vom Typ Ihrer struct.
 *    Definieren Sie zusätzlich die Datentyp-Bezeichnung node_t für Ihre struct.
 * b) Schreiben Sie eine Funktion node_t* add_element_sorted(node_t* head, int v), welche das neue Element v in die
 *    Liste sortiert einfügt. Der aktuelle Head soll dafür an die Funktion übergeben werden und der eventuell geänderte
 *    Head nach dem Einfügen zurückgegeben werden. Im Gegensatz zur Vorlesung ist der Head keine globale Variable.
 * c) Schreiben Sie eine Funktion, die Ihre Liste auf der Kommandozeile ausgibt.
 * d) Schreiben Sie eine main-Funktion und überprüfen Sie in dieser, ob genügend Parameter übergeben wurden und lesen
 *    Sie die beiden Anzahlen von der Kommandozeile aus. Zeichenketten können mittels strtol in longs umgewandelt
 *    werden. Erzeugen Sie eine Liste mit der übergebenen Anzahl an Elemente mit Zufallswerten und geben Sie die Liste
 *    auf der Kommandozeile aus.
 * e) Portieren Sie die Funktion remove_element mit doppelten Zeigern aus der Vorlesung.
 *    Passen Sie die Funktion dahingehend an, dass der Head der Liste übergeben wird und
 *    der aktuelle Head nach dem Entfernen zurückgegeben wird.
 * f) Erweitern Sie nun Ihre main-Funktion und entfernen Sie nach dem Einfügen der Elemente die übergebene Anzahl
 *    an Elementen. Speichern Sie die eingefügten Werte auch in einem int-Array. Verwenden Sie dieses Array, um einen
 *    zu entfernenden Wert per Zufall aus diesem Array auszuwählen. Geben Sie die Liste zur Kontrolle vor und nach dem
 *    Entfernen auf der Kommandozeile aus.
 */
 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>


struct list_node {
	int32_t value;
	struct list_node* next;
};

typedef struct list_node node_t;


node_t* add_element_sorted(node_t* head, int32_t v) {
	node_t** curr = &head;

	node_t* new_node = (node_t*) malloc(sizeof(node_t));
	if (new_node == NULL) {
		printf("Allocation error!\n");
		exit(-1);
	}
	new_node->value = v;

	while (*curr != NULL && (*curr)->value < v) {
		curr = &(*curr)->next;
	}

	if (*curr == head) {
		new_node->next = head;
		return new_node;
	} else {
		new_node->next = *curr;
		*curr = new_node;
		return head;
	}
}


node_t* remove_element(node_t* head, int32_t v) {
	node_t** curr = &head;
	node_t* entry;

	while (*curr != NULL) {
		entry = *curr;
		if (entry->value == v) {
			*curr = entry->next;
			free(entry);
			if (entry == head) {
				return entry->next;
			} else {
				return head;
			}
		} else {
			curr = &entry->next;
		}
	}

	printf("%d not in list.\n", v);
	return head;
}


void print_list(node_t* head) {
	node_t* curr  = head;

	printf("List: ");
	while (curr != NULL) {
		printf("%d", curr->value);
		curr = curr->next;
        if (curr!=NULL)
			printf(", ");
	}
	printf("\n");
}


int main (int argc, char* argv[]) {
	if (argc != 3) {
		printf("Usage: list <Number of elements to add> <number of elements to remove>\n");
		exit(-1);
	}
	long nadd = strtol(argv[1], NULL, 10);
	long nremove = strtol(argv[2], NULL, 10);

	if (nremove > nadd) {
		printf("Number of elements to remove higher than number of elements to add. Setting the former to %ld.\n", nadd);
		nremove = nadd;
	}

  srand(time(NULL));

	int32_t helper[nadd];

	node_t* head = NULL;
	for (int i = 0; i < nadd; i++) {
		int32_t el = rand() % 100;
		head = add_element_sorted(head, el);
        helper[i] = el;
	}
	print_list(head);

	for (int i = 0; i < nremove; i++) {
		int32_t el = rand() % nadd;
		printf("Removing %d ...\n", helper[el]);
		head = remove_element(head, helper[el]);
	}
    print_list(head);
}
