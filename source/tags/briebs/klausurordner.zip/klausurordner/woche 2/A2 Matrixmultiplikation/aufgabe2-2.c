/* Musterlösung zur Aufgabe 'Matrixmultiplikation'
 *
 * In dieser Aufgabe sollen Sie zwei Matrizen A und B erzeugen und diese mit Zufallswerten füllen. Anschließend sollen
 * die beiden Matrizen multipliziert werden, wobei das Resultat in eine dritte Matrix C geschrieben werden soll.
 * Die Matrizengrößen sind frei wählbar, es muss allerdings gelten:
 *    Anzahl Reihen MatrixA == Anzahl Spalten MatrixB
 * und
 *    Anzahl Spalten MatrixA == Anzahl Reihen MatrixB.
 *
 * a) Definieren Sie die Anzahl an Zeilen und Spalten der Matrizen A und B per Makro. Allozieren Sie anschließend in
 *    der main-Funktion den Speicher für alle drei Matrizen auf dem Heap (mittels malloc). Wählen Sie als Datentyp
 *    für einen Eintrag in einer Matrix uint64_t.
 * b) Schreiben Sie eine Funktion initializeMatrix(uint64_t * matrix, int rows, int colums), die eine übergebene Matrix
 *    mit Zufallszahlen aus dem Intervall [0, 100) initialisiert. Rufen Sie die Funktion für beide Matrizen A und B auf.
 * c) Schreiben Sie nun eine Funktion multiplyMatrices, welche die beiden Matrizen A und B multipliziert und
 *    das Ergebnis in die Matrix C schreibt.
 */

#include <stdlib.h>  // Fuer calloc, exit, free, malloc, rand, srand
#include <stdio.h>   // Fuer printf
#include <time.h>    // Fuer time

#define RA  5
#define CA  3
#define RB  3
#define CB  5

#define getAddress(matrix_pointer, current_row, current_column, columns) \
    (matrix_pointer + current_row * columns + current_column)

void initializeMatrix(int64_t* matrix, int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            *getAddress(matrix, i, j, cols) = rand() % 100;
        }
    }
}

void multiplyMatrices(int64_t* matrixA, int64_t* matrixB, int64_t* matrixC,
        int rowsA, int colsA, int colsB) {
    for (int i = 0; i < rowsA; i++) {
        for(int j = 0; j < colsB; j++) {
            for (int k = 0; k < colsA; k++) {
                *getAddress(matrixC, i, j, colsB) +=
                        *getAddress(matrixA, i, k, colsA) *
                        *getAddress(matrixB, k, j, colsB);
            }
        }
    }
}

void printMatrix(int64_t* matrix, int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            printf("%lld ", *getAddress(matrix, i, j, cols));
        }
        printf("\n");
    }
}

int main() {
    if (RA != CB || CA != RB) {
        printf("Ungueltige Dimensionen der Matrizen: Die Zeilenanzahl der Matrix A "
                "muss der Spaltenanzahl der Matrix B gleichen und umgekehrt.\n");
        exit(-1);
    }

    int64_t* matrixA = malloc(RA * CA * sizeof(int64_t));
    int64_t* matrixB = malloc(RB * CB * sizeof(int64_t));
    int64_t* matrixC = calloc(RA * CB, sizeof(int64_t));

    if (matrixA == NULL || matrixB == NULL || matrixC == NULL) {
        printf("ERROR: Allokation fehlgeschlagen.\n");
        exit(-1);
    }

    srand(time(NULL));
    initializeMatrix(matrixA, RA, CA);
    initializeMatrix(matrixB, RB, CB);

    multiplyMatrices(matrixA, matrixB, matrixC, RA, CA, CB);

    printf("Matrix A:\n");
    printMatrix(matrixA, RA, CA);

    printf("\nMatrix B:\n");
    printMatrix(matrixB, RB, CB);

    printf("\nMatrix C (A mal B):\n");
    printMatrix(matrixC, RA, CB);

    free(matrixA);
    free(matrixB);
    free(matrixC);
    return 0;
}