#include <stdio.h>

#define BUFFER_SIZE 1000

char buff[BUFFER_SIZE];

/*
 Lots of other functions that manipulate buf...
 */
