/* Musterlösung zur Aufgabe 'Studentenkartei', Teil 2
 *
 * In dieser Aufgabe sollen Sie eine kleine Studentenkartei für bis zu zehn Studenten programmieren. Für jeden Student
 * soll eine eindeutige ID gespeichert werden, sowie der Name und eine Note
 *
 * a) Erstellen Sie folgende Datentypen und lokale Variablen:
 *    - Definieren Sie eine struct mit einer ID (int), einem Namen (char-Array der festen Länge 10) und einer
 *      Note (float). Weisen Sie Ihrer struct die Datentyp-Bezeichnung student_t zu.
 *    - Definieren Sie ein Array vom Datentyp student_t mit 10 Einträgen.
 *    - Definieren Sie eine lokale Variable char *name mit einem Zeiger auf die Zeichenkette "Student"
 *    Initialisieren Sie die 10 Einträge des Arrays mit einer Schleife wie folgt:
 *    - ID: soll aufsteigend vergeben werden, also 0 bis 9.
 *    - Name: soll jeweils aus "Student" und der angehängten ID bestehen, also Student0 bis Student9. Die ID soll
 *      angehängt werden, indem die betroffenen Zeichen innerhalb der Zeichenkette im struct manipuliert werden
 *      (Zugriff mit eckigen Klammern).
 *    - Note: kann beliebig gewählt werden.
 *    Geben Sie zur Kontrolle alle Felder aller Studenten aus.
 * b) Ändern Sie Ihr Programm und legen Sie den Speicher für die 10 Studenten (student_t) mithilfe von malloc an
 *    (statt dem Array) und geben Sie den Speicher am Ende des Programms wieder frei.
 * c) Nun soll das Programm nochmals modifiziert werden. Hängen Sie die ID and die Zeichenkette an, indem Sie
 *    direkt auf die bytegenaue Adresse zugreifen (ohne eckige Klammern, sondern mithilfe eines char* Zeigers).
 *
 * Lösung zu Aufgabenteil (b):
 */

#include <stdio.h>  // Fuer printf
#include <string.h> // Fuer strcpy
#include <stdlib.h> // Fuer malloc

#define STUDENT_COUNT 10

typedef struct {
    int   id;
    char  name[10];
    float note;
} student_t;

int main() {
    student_t *students = malloc(sizeof(student_t) * STUDENT_COUNT);
    char *name = "Student";

    for (int i = 0; i < STUDENT_COUNT; i++) {
        students[i].id = i;
        students[i].note = 1.0 + (i%4);
        strcpy(students[i].name, name);
        *((char*)(students + i) + sizeof(int) + 7) = i + '0';
        *((char*)(students + i) + sizeof(int) + 8) = '\0';
    }

    for (int i = 0; i < STUDENT_COUNT; i++) {
        printf("%d. Student:\n", i+1);
        printf("  ID: %d \n", students[i].id);
        printf("  Name: %s \n", students[i].name);
        printf("  Note: %.1f\n\n",students[i].note);
    }

    free(students);
    return 0;
}