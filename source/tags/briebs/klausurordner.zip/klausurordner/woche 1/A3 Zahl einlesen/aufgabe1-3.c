/* Musterlösung zur Aufgabe 'Zahl einlesen'
 * Schreiben Sie ein Programm, das eine natürliche Zahl von der Konsole einliest.
 *
 * a) Lesen Sie zunächst zeichenweise mit getchar die Eingabe ein und schreiben Sie die chars in ein Array,
 *    das Sie zuvor mittels malloc alloziert haben.
 * b) Das Programm soll mit einer Fehlermeldung beendet werden, sobald ein ungültiges Zeichen gelesen wurde.
 * c) Definieren Sie die Array-Größe mit einem Makro und achten Sie darauf, dass Sie nicht über die Arraygrenzen
 *    hinaus schreiben.
 * d) Geben Sie zum Schluss die gültige natürliche Zahl aus.
 */
 
#include <stdio.h>  // Fuer getchar und printf
#include <stdlib.h> // Fuer exit und malloc

#define ARRAY_LENGTH 11

int main() {
    char *array = malloc(sizeof(*array) * ARRAY_LENGTH);
    if (array == NULL) {
        printf("ERROR: Allokation fehlgeschlagen.\n");
        exit(-1);
    }

    int ch, position = 0;
    printf("Geben Sie eine natuerliche Zahl ein: ");
    while ((ch = getchar()) != EOF && ch != '\n') {
        if (position >= ARRAY_LENGTH - 1) {
            printf("ERROR: Zahl ist zu gross.\n");
            free(array);
            exit(-1);
        }

        if (ch < '0' || '9' < ch) {
            printf("ERROR: Dies ist keine natuerliche Zahl.\n");
            free(array);
            exit(-1);
        }

        array[position] = ch;
        position++;
    }
    array[position] = '\0';
    printf("Die eingegebene Zahl ist: %s\n", array);
    
    free(array);
    return 0;
}