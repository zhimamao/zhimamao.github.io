/* Musterlösung zur Aufgabe 'Fahrkartenautomat', Teil 2
 *
 * Bei einem Fahrkartenautomat kommt es häufig vor, dass ein Kunde den Fahrpreis nicht genau bezahlt. Der Automat
 * muss dann Wechselgeld herausgeben.
 *
 * a) Schreiben Sie für die Berechnung des Wechselgelds eine Funktion calc_coins, welche einen Geldbetrag (in Cent)
 *    übergeben bekommt und jeweils die Anzahl der 50 Cent, 20 Cent, 5 Cent, 2 Cent und 1 Cent Münzen berechnet,
 *    die der Automat ausgeben muss. Schreiben Sie ein Hauptprogramm (automat.c), in welchem der Benutzer zur Eingabe
 *    des Wechselgeldbetrags aufgefordert wird. Das Programm soll dann mithilfe der Funktion calc_coins alle Münzen
 *    ausgeben, die der Automat zurückgeben muss, sodass die Gesamtanzahl an Münzen minimal ist.
 * b) Lagern Sie nun die Berechnung (die Funktion calc_coins) in eine weitere c-Datei aus.
 * c) Schreiben Sie abschließend ein Makefile, das das komplette Modul kompiliert.
 *
 * Lösung zu Teil (b):
 */

#include <stdio.h>  // Fuer printf
#include <stdlib.h> // Fuer exit
#include "calc.h"

int main() {
    int amount;
    int coins[] = {50, 20, 5, 2, 1};

    printf("Geben Sie den Geldbetrag in Cent ein: ");
    if (scanf("%d", &amount) != 1) {
        printf("ERROR: Ungueltigen Wert eingegeben. Abbruch.\n");
        exit(-1);
    }

    for(int i = 0; i < 5; i++){
        amount = calc_coins(coins[i], amount);
    }

    return 0;
}