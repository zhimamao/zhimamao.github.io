/* Musterlösung zur Aufgabe 'Parallele Berechnung mit Threads'
 *
 * Schreiben Sie ein C-Programm, welches mithilfe von Threads parallel das Maximum in einem Integer-Array sucht und
 * ausgibt. Der Haupt-Thread soll hierzu ein größeres Integer-Array allozieren und mit Zufallszahlen befüllen.
 * Anschließend soll er eine einstellbare Anzahl an Worker-Threads erzeugen die jeweils das Maximum in einem
 * Teilbereich des 1Arrays suchen. Die Teilergebnisse sollen als Rückgabewert der Threadfunktion zurückgegeben werden
 * und im Haupt-Thread in einem separaten Integer-Array gespeichert werden. Der Haupt-Thread soll, wenn alle Threads
 * fertig sind das Maximum der ermittelten Maxima berechnen und ausgeben. Messen Sie anschliessend die
 * Ausführungszeiten mit verschiedenen Worker-Thread-Anzahlen, beispielsweise 1, 2, 4 und 8.
 *
 * Hinweise:
 * - Für die Zeitmessung können Sie beispielsweise den Aufruf clock in time.h verwenden.
 * - Verwenden Sie für die Array-Größe eine 2er-Potenz, sowie auch für die Anzahl der Worker-Threads.
 * - Zerlegen Sie das Array in gleich große Stücke.
 */

#include <limits.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>


/* fill array with random numbers */
void fill_array(int* arr, int length) {
    for (int i = 0; i < length; i++) {
        *(arr + i) = random() % 1000000;
    }
}


/* parameter for thread function */
typedef struct parameters {
    int* arr;
    int offset;
    int length;
} param_t;


/* thread fuction */
void* get_maximum_parallel(void* data) {
    long *max = malloc(sizeof(long));
    int *arr = ((param_t*) data)->arr;
    int offset = ((param_t*) data)->offset;
    int length = ((param_t*) data)->length;

    /* search maximum in given part */
    for (int i = offset; i < offset + length; i++) {
        int value = *(arr + i);
        if (value > *max) {
            *max = value;
        }
    }
    free(data);

    return (void*) max;
}


int get_maximum(int* arr, int length) {
    int max = 0;

   for (int i = 0; i < length; i++) {
        int value = *(arr + i);
        if (value > max) {
            max = value;
        }
    }

    return max;
}


int main (int argc, const char* argv[]) {
    /*
       Check arguments
    */
    if (argc != 3) {
        printf("Usage: maximum <array length> <number of threads>\n");
        exit(EXIT_FAILURE);
    }

    long array_length = strtol(argv[1], NULL, 10);
    if (array_length < 0 || array_length > INT_MAX || array_length & (array_length - 1)) {
        printf("Invalid array length: %ld\n", array_length);
        exit(EXIT_FAILURE);
    }
    printf("array_length=%ld\n", array_length);

    long threads = strtol(argv[2], NULL, 10);
    if (threads < 0 || threads > 16 || threads & (threads - 1)) {
        printf("Invalid number of threads: %ld\n", threads);
        exit(EXIT_FAILURE);
    }

    /*
       Initialization
     */
    printf("Initializing...\n");
    srand(time(NULL));

    /* allocate & fill data array */
    int* arr = (int*) malloc(sizeof(int) * array_length);
    if (arr == NULL) {
        printf("Not enough memory\n");
        exit(EXIT_FAILURE);
    }
    fill_array(arr, array_length);

    /* array for result of each thread */
    int* results = (int*) malloc(sizeof(int) * threads);
    if (results == NULL) {
        printf("Not enough memory\n");
        exit(EXIT_FAILURE);
    }

    /*
       Starting parallel computation
     */
    printf("Starting...\n");
    struct timespec start, end;
    clock_gettime(CLOCK_MONOTONIC, &start);

    pthread_t pthreads[threads];
    for (int i = 0; i < threads; i++) {

        param_t* data = (param_t*) malloc(sizeof(param_t));
        data->arr = arr;
        data->offset = i * (array_length / threads);
        data->length = array_length / threads;

        if (pthread_create(&pthreads[i], NULL, get_maximum_parallel, data) != 0) {
            printf("Could not create threads\n");
            exit(EXIT_FAILURE);
        }
    }

    /*
       Wait for each thread to terminate and store each result in 'results' array
     */
    void* ret_ptr = NULL;
    for (int i = 0; i < threads; i++) {
        pthread_join(pthreads[i], &ret_ptr);
        *(results + i) = * ((long *)ret_ptr);
        free(ret_ptr);
    }

    clock_gettime(CLOCK_MONOTONIC, &end);

    /* get and print maximum from results */
    printf("Maximum: %d; determined in %ld ms\n", get_maximum(results, threads),
        (end.tv_sec - start.tv_sec) * 1000 + (end.tv_nsec - start.tv_nsec) / 1000 / 1000);

    free(arr);
    free(results);
}
