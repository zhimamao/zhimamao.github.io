/* libhello.h */

void hello(char *msg);
