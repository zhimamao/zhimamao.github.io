/* Mustserlösung zur Aufgabe 'Datei vom proc-Dateisystem einlesen', Variante 2
 *
 * In der Vorlesung haben Sie Funktionen zum Zugriff auf Dateien kennengelernt (open, close, read und write).
 * Zusätzlich haben Sie erfahren, dass Linux Systeminformationen im proc-Dateisystem (unter /proc) ablegt. In dieser
 * Aufgabe sollen Sie nun die beiden Erkenntnisse kombinieren, indem Sie die Datei /proc/meminfo auslesen und die
 * Menge an freien und gesamten Speicher sowie die Größe des Page-Caches (Cached) in dieser Reihenfolge ausgeben.
 */

#include <fcntl.h>   // Fuer open
#include <stdlib.h>  // Fuer free, malloc
#include <stdio.h>   // Fuer printf, fscanf
#include <unistd.h>  // Fuer close, read

#define BUFF_SIZE  1024

int main() {
    char unit1[3], unit2[3], unit3[3];
    int mem_total, mem_free, cached;

    FILE* fd = fopen("/proc/meminfo", "r");

    fscanf(fd, "%*s %d %2s"
           "%*s %d %2s"
           "%*s %*d %*s"
           "%*s %d %2s",
        &mem_total, unit1,
        &mem_free, unit2,
        &cached, unit3);

    fclose(fd);

    printf("Groesse des gesamten Speichers: %d %s\n", mem_total, unit1);
    printf("Groesse des freien Speichers:   %d %s\n", mem_free, unit2);
    printf("Groesse des Page-Cache:         %d %s\n", cached, unit3);
}