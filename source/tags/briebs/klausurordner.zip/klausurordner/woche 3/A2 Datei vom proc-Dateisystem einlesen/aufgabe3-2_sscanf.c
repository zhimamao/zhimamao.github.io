/* Mustserlösung zur Aufgabe 'Datei vom proc-Dateisystem einlesen', Variante 1
 *
 * In der Vorlesung haben Sie Funktionen zum Zugriff auf Dateien kennengelernt (open, close, read und write).
 * Zusätzlich haben Sie erfahren, dass Linux Systeminformationen im proc-Dateisystem (unter /proc) ablegt. In dieser
 * Aufgabe sollen Sie nun die beiden Erkenntnisse kombinieren, indem Sie die Datei /proc/meminfo auslesen und die
 * Menge an freien und gesamten Speicher sowie die Größe des Page-Caches (Cached) in dieser Reihenfolge ausgeben.
 */

#include <fcntl.h>   // Fuer open
#include <stdlib.h>  // Fuer free, malloc
#include <stdio.h>   // Fuer printf, fscanf
#include <unistd.h>  // Fuer close, read

#define BUFF_SIZE  1024

int main() {
    char* buffer = malloc(BUFF_SIZE * sizeof(*buffer));
    if (buffer == NULL) {
        printf("ERROR: Allokation mit malloc fehlgeschlagen.\n");
        exit(EXIT_FAILURE);
    }

    char unit1[3], unit2[3], unit3[3];
    int mem_total, mem_free, cached;

    int fd = open("/proc/meminfo", O_RDONLY);

    if (read(fd, buffer, BUFF_SIZE) < 1) {
        printf("ERROR: Einlesen mit read fehlgeschlagen.\n");
        exit(EXIT_FAILURE);
    }

    close(fd);

    sscanf(buffer, "%*s %d %2s"
                   "%*s %d %2s"
                   "%*s %*d %*s"
                   "%*s %d %2s",
            &mem_total, unit1,
            &mem_free, unit2,
            &cached, unit3);

    printf("Groesse des gesamten Speichers: %d %s\n", mem_total, unit1);
    printf("Groesse des freien Speichers:   %d %s\n", mem_free, unit2);
    printf("Groesse des Page-Cache:         %d %s\n", cached, unit3);
}