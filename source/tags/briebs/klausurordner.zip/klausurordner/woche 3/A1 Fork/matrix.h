void initializeMatrix(int64_t* matrix, int rows, int cols);

void multiplyMatrices(int64_t* matrixA, int64_t* matrixB, int64_t* matrixC,
        int rowsA, int colsA, int colsB);