/* Musterlösung zur Aufgabe 'Fork'
 *
 * Schreiben Sie ein Programm, das mithilfe des Systemaufrufs fork eine Prozesskopie erstellt. Anschließend soll der
 * Vaterprozess sekündlich die bereits verstrichene Zeit (in Sekunden) ausgeben bis sich der Kindprozess beendet hat.
 * Der Kindprozess soll zwei Matrizen multiplizieren.
 *
 * Tipp 1: Nutzen Sie Ihre Lösung vom vorherigen Übungsblatt oder die Vorlage von der Veranstaltungsseite für
 * die Matrizenmultiplikation. Wählen Sie die Dimensionen der Matrizen entsprechend groß, damit der Kindprozess
 * mehrere Sekunden beschäftigt ist.
 *
 * Tipp 2: Damit der Aufruf waitpid nicht blockiert, müssen Sie den entsprechenden Parameter übergeben. Betrachten 
 * Sie dazu die man-Page von waitpid (man waitpid). Den Statuswert können Sie nutzen um festzustellen, ob der Prozess
 * beendet wurde.
 */

#include <stdio.h>   // Fuer printf, scanf
#include <stdlib.h>  // Fuer exit, rand, srand
#include <string.h>  // Fuer 
#include <time.h>    // Fuer time
#include <unistd.h>  // Fuer fork, sleep
#include <wait.h>    // Fuer waitpid
#include "matrix.h"

int main () {
    int rows, columns;

    printf("Bitte Anzahl der Zeilen eingeben: ");
    if (scanf("%d", &rows) != 1 || rows < 1) {
        printf("ERROR: Dies ist keine natuerliche Zahl.\n");
        exit(-1);
    }
    printf("Bitte Anzahl der Spalten eingeben: ");
    if (scanf("%d", &columns) != 1 || columns < 1) {
        printf("ERROR: Dies ist keine natuerliche Zahl.\n");
        exit(-1);
    }

    pid_t pid = fork();
    if (pid == (pid_t) 0) {
        // Kindprozess
        int64_t* matrixA = malloc(rows * columns * sizeof(*matrixA));
        int64_t* matrixB = malloc(rows * columns * sizeof(*matrixB));
        int64_t* matrixC = calloc(rows * columns, sizeof(*matrixC));

        if (matrixA == NULL || matrixB == NULL || matrixC == NULL) {
            printf("ERROR: Allokation fehlgeschlagen.\n");
            exit(-1);
        }

        srand(time(NULL));
        initializeMatrix(matrixA, rows, columns);
        initializeMatrix(matrixB, rows, columns);

        multiplyMatrices(matrixA, matrixB, matrixC, rows, columns, columns);

        free(matrixA);
        free(matrixB);
        free(matrixC);
    } else {
        // Elternprozess
        int status = -1;
        int seconds = 0;

        while (status == -1) {
            waitpid(pid, &status, WNOHANG);

            printf("Warte auf Kindprozess: %d Sekunden\n", seconds);
            sleep(1);
            seconds++;
        }

        printf("Kindprozess beendet mit Statuscode: %x\n", status);
    }

    return 0;
}