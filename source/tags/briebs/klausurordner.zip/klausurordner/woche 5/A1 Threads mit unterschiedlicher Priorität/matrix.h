void initializeMatrix(long long* matrix, int rows, int cols);
void multiplyMatrices(long long* matrixA, long long* matrixB, long long* matrixC, int rowsA, int colsA, int colsB);