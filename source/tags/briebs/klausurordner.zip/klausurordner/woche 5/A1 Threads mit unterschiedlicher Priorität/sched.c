/* Musterlösung zur Aufgabe 'Parallele Berechnungen mit unterschiedlicher Priorität'
 *
 * In dieser Aufgabe sollen Sie ein C-Programm schreiben, welches die Matrizenmultiplikation aus Übungsblatt 2 mehrfach
 * nebenläufig durchführt. Mehrere Threads bekommen als Eingabe dieselben Matrizen A und B und berechnen jeweils die
 * Ergebnismatrix C. Hierzu muss jeder Thread den Speicher für seine Matrix C selbst allozieren. Die Ergebnisse sollen
 * nicht ausgegeben werden.
 * Ziel ist, dass alle Threads die gleiche Rechenaufgabe durchführen. Ein Thread von allen erzeugten Threads soll in
 * SCHED_FIFO mit Priorität 99 ablaufen (siehe Beispiel aus der Vorlesung). Der Haupthread soll warten bis alle Threads
 * terminiert haben und dann die Zeiten (siehe auch Hinweise) ausgeben, vom schnellsten und langsamsten Thread. Wir
 * erwarten, dass der Thread mit der höchsten Priorität am schnellsten das Ergebnis liefert, da er bei der CPU-Zuteilung
 * bevorzugt wird.
 *
 * Hinweise:
 * - Führen Sie die Matrizenmultiplikation mit einer großen Anzahl an Threads aus
 *   (Anzahl Threads > Anzahl Kerne inklusive Hyperthreading).
 * - Das Verschieben des Threads in die FIFO-Queue erfordert root-Rechte. Führen Sie dazu das Programm mit den
 *   entsprechenden Rechten aus (z.B. sudo ./myprog). Ob das Scheduling des Treads tatsächlich geändert wurde,
 *   können Sie mit top -H erkennen (in der Spalte PR muss für den Thread RT erscheinen).
 * - Neben der Spalten- und Zeilenanzahl für die Matrizen soll auch die Thread-Anzahl vom Terminal als Argument
 *   übergeben werden.
 * - Die Zeitmessung, wie lange die Berechnung einer Matrizenmultiplikation dauert, muss jeder Thread selbst durchführen
 *   und die Zeitdauer als Rückgabewert an den Hauptthread zurückgeben.
 * - Für die Zeitmessung wird der Systemaufruf clock_gettime empfohlen, siehe man-Pages.
 */

#include <limits.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "matrix.h"


typedef struct parameters {
    long long* matrixA;
    long long* matrixB;
    int rows;
    int columns;
} param_t;

void set_prio(pthread_t id, int policy, int prio) {
   struct sched_param param;

   param.sched_priority = prio;

   if ((pthread_setschedparam(id, policy, &param)) != 0) {
      printf("error: unable to change scheduling strategy.\n");
      pthread_exit((void *) id);
   }
}

void* run(void* data) {
    long* ret = (long*) malloc(sizeof(long));
    long long* matrixA = ((param_t*) data)->matrixA;
    long long* matrixB = ((param_t*) data)->matrixB;
    int rows = ((param_t*) data)->rows;
    int columns = ((param_t*) data)->columns;

    struct timespec start, end;
    clock_gettime(CLOCK_MONOTONIC, &start);

    long long* matrixC = (long long*)calloc(rows * columns, sizeof(long long));
    if (ret == NULL || matrixC == NULL) {
        printf("Allocation error!");
        exit(EXIT_FAILURE);
    }

    multiplyMatrices(matrixA, matrixB, matrixC, rows, columns, columns);

    clock_gettime(CLOCK_MONOTONIC, &end);
    *ret = (end.tv_sec - start.tv_sec) * 1000 + (end.tv_nsec - start.tv_nsec) / 1000 / 1000;

    free(matrixC);

    return (void*) ret;
}


int main (int argc, const char* argv[]) {
    if (argc != 4) {
        printf("Usage: maximum <#rows> <#columns> <#threads>\n");
        exit(EXIT_FAILURE);
    }

    long rows = strtol(argv[1], NULL, 10);
    if (rows < 0 || rows > INT_MAX) {
        printf("Invalid number of rows: %ld\n", rows);
        exit(EXIT_FAILURE);
    }
    long columns = strtol(argv[2], NULL, 10);
    if (columns < 0 || columns > INT_MAX) {
        printf("Invalid number of columns: %ld\n", columns);
        exit(EXIT_FAILURE);
    }
    long threads = strtol(argv[3], NULL, 10);
    if (threads < 0 || threads > 16) {
        printf("Invalid number of threads: %ld\n", threads);
        exit(EXIT_FAILURE);
    }

    printf("Initializing...\n");

    long long* matrixA = (long long*)malloc(rows * columns * sizeof(long long));
    long long* matrixB = (long long*)malloc(rows * columns * sizeof(long long));
    if (matrixA == NULL || matrixB == NULL) {
        printf("Allocation error!");
        exit(EXIT_FAILURE);
    }

    srand (time( NULL));
    initializeMatrix(matrixA, rows, columns);
    initializeMatrix(matrixB, columns, rows);

    printf("Starting...\n");

    param_t* data = (param_t*) malloc(sizeof(param_t));
    data->matrixA = matrixA;
    data->matrixB = matrixB;
    data->rows = rows;
    data->columns = columns;

    pthread_t pthreads[threads];
    for (int i = 0; i < threads; i++) {
        if (pthread_create(&pthreads[i], NULL, run, data) != 0) {
            printf("Could not create threads\n");
            exit(EXIT_FAILURE);
        }
        if (i == threads - 1) {
            set_prio(pthreads[i], SCHED_FIFO, 99);
        }
    }

    long min = INT_MAX;
    long max = 0;
    int min_index = -1;
    int max_index = -1;
    void* ret_ptr = NULL;
    for (int i = 0; i < threads; i++) {
        pthread_join(pthreads[i], &ret_ptr);
        long value = *((long*) ret_ptr);
        printf("Thread %d finished: %ld ms\n", i, value);
        if (value >= max) {
            max = value;
            max_index = i;
        }
        if (value <= min) {
            min = value;
            min_index = i;
        }
        free(ret_ptr);
    }

    printf("Slowest thread was thread %d: %ld ms\n", max_index, max);
    printf("Fastest thread was thread %d: %ld ms\n", min_index, min);

    free(data);
    free(matrixA);
    free(matrixB);
}