#include <fcntl.h>	/* for open() 				        */
#include <stdio.h>	/* for printf()				        */
#include <unistd.h>	/* for read(), write(), close() 	*/
#include <string.h>  
#include <stdlib.h>


#define BUFF_SIZE   256


char buf[BUFF_SIZE];

int main( int argc, char **argv ) {
	int fd, i, toread;
    int read_bytes, written_bytes;

	if ( argc < 4 ) {
		printf("test: usage 'test dev_file' w <string> | r <bytes> \n");
		return -1;
	}

	fd = open( argv[1], O_RDWR );
	if ( fd < 0 ) { 
		printf("test: error opening file\n");  
		return -1; 
	}
	printf("test: opened '%s' successfully.\n", argv[1]);  

    if (argv[2][0]=='w') {
       int total_written=0;
       for (i=0; i<strlen(argv[3]); i++) {
          written_bytes = write( fd, (void*)&argv[3][i], 1 );
          if (written_bytes==0) {
	         printf("test: write failed, aborting.\n");
             exit(1);  
          }
          total_written += written_bytes;
       }
	   printf("test: number of bytes written = %d, of string = '%s' successfully.\n", total_written, argv[3]);  
    } else if (argv[2][0]=='r') {
       toread = atoi(argv[3]);
       i = 0;
       while(toread>0) {
          read_bytes = read( fd, (void*)&buf[i], 1 );
          if (read_bytes==0) {
	         printf("test: read failed, aborting.\n");
             exit(1);  
          }
          i++;
          toread--; 
       }
       buf[i] = '\0';
	   printf("test: number of bytes read = %d, string = '%s' successfully.\n", atoi(argv[3]), buf);  
    } else {
	   printf("test: usage 'test dev_file' w <string> | r <bytes> \n");
       close( fd );
	   return -1;
    }

	close( fd );
}
