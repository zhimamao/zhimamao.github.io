/* Testprogramm zur Ausführung des Shellcodes
 * zu Betreibssysteme und Systemprogrammierung, Blatt 12, Aufgabe 3
 * ================================================================
 * Author: Florian Dittrich
 *
 * Kompilieren und Ausführen mit
 *   gcc -m32 test_execve.c -g -z execstack -o test_execve
 *   ./test_execve
 */

#include <stdio.h>   // Für printf
#include <stdlib.h>  // Für malloc
#include <string.h>  // Für memcpy

// Der mit touch_hacked.asm erzeugte Shellcode
char shellcode[] = "\x31\xC0\xEB\x39\x8B\x5C\x24\x0C\x31\xC9\xB1\x05\x80\xC1\x05\x88\x04\x0B\x89\xE1\x8B\x11\x88\x42\x05\x8B\x51\x04\x88\x42\x06\x31\xD2\xB0\x0B\xCD\x80\xE8\xDA\xFF\xFF\xFF\x74\x6F\x75\x63\x68\x30\x50\xE8\xEF\xFF\xFF\xFF\x68\x61\x63\x6B\x65\x64\x30\xE8\xEE\xFF\xFF\xFF\x2F\x62\x69\x6E\x2F\x74\x6F\x75\x63\x68\x30";

int main(int argc, char *argv[]) {
    // Zuerst den Shellcode in einen Speicherbereich kopieren, in den auch geschrieben werden darf.
    char* mem = malloc(280);
    memcpy(mem, shellcode, 280);

    // Nun den Shellcode ausführen
    void (*shell)() = (void*)mem;
    shell();

    printf("Diese Zeile sollte niemals ausgegeben werden.\n");
}
