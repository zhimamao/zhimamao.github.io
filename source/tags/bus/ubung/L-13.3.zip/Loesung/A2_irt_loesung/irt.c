/* original author: Allan B. Cruse 	*/
#include <linux/module.h>		/* for module_init() 		*/
#include <linux/types.h>        /* kernel types, e.g. u32   */


char *seg_types[] = {	
            "Task Gate     ",
			"Interrupt Gate",
			"Trap Gate     "
		    };


unsigned short 	idtr[3];	/* 6 bytes limit:0..15, base: 16..47 */

static u32 irt_get_idt_address(void) {
	u32 idt_vaddr; 
	u32 i;

    /* init array */
	for (i=0; i<3; i++) idtr[i] = -1;

	/* use inline assembly language to get IDTR content */
	asm(" sidt idtr ");

	/* extract IDT virtual-address */
	idt_vaddr = *(unsigned long*)(idtr+1);

	return idt_vaddr;
}	

/* this function must be called adfter 'irt_get_idt_address' */
static u32 irt_get_descriptor_count(void) {
	return (1 + idtr[0])/8;
}

/* dump idt */
static void irt_dump(void) {
    u32 idt_entries;
	u64	*idt_ptr;     /* ptr to current IDT entry */
    u64	idt_entry;    /* content of one IDT entry */

	u32	i,typ,dpl,sel,off;


    idt_ptr = (u64*)irt_get_idt_address();

    idt_entries = irt_get_descriptor_count();
   	printk( "irt: idt_vaddr       = %08X\n", (u32)idt_ptr );
	printk( "irt: idt entries cnt = %08X\n", idt_entries );


	for (i=0; i<idt_entries; i++) {
        idt_entry = *idt_ptr;

		typ   = ((idt_entry >> 40) & 0x3) - 1;
		dpl   = (idt_entry >> 45) & 0x3;
		sel   = (idt_entry >> 48);
		off   = (idt_entry & 0xFFFF);
		off   = off | (((idt_entry >> 48) & 0xFFFF) << 16);


		printk("irt: %04x: type: %s, dpl=%d, seg-sel: %d", i, seg_types[typ], dpl, sel);
		/*if (typ!=0) 	
			printk(", seg-offl: %x\n", off);
		else
			printk("\n");
*/
		idt_ptr++;		
	}

}

static int irt_init( void ) {
	printk( "irt: module loaded.\n");
    irt_dump();
   	return 	0;
}

static void irt_exit( void ) {
	printk( "irt: module unloaded\n");
}

MODULE_LICENSE("GPL");
module_init( irt_init );
module_exit( irt_exit );

