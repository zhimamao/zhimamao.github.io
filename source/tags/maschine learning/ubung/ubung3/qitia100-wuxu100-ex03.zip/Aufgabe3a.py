
import scipy.integrate as si


a = sc.special.beta(91,11)
b = sc.special.beta(3,1)
print(a)
def fun(a,b):
    print a*b
#1
#q = si.dblquad(fun,0,1,0,1 )


